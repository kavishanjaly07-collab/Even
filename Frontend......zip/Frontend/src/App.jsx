
import { Routes, Route } from "react-router-dom";

import Home from "./components/home";
import Login from "./components/Login/Login";
import Register from "./Register/Register";

import Customerhome from "./components/ClientDashboard/CustomerHome";
import BrowseServices from "./components/ClientDashboard/BrowseServices";
import EventConnectBookings from "./components/ClientDashboard/EventConnectBookings";
import EventConnectProfile from "./components/ClientDashboard/EventConnectProfile";
import EventConnectMessages from "./components/ClientDashboard/EventConnectMessages";
import { MyReviews, PaymentsBudget } from "./components/ClientDashboard/ClientDashboardPages";
import Payment from "./components/Payment/Payment";
import AdminDashboard from "./components/AdminDashboard/AdminDashboard";
import ProviderDashboard from "./components/ProviderDashboard/ProviderDashboard";
import ProviderHome from "./components/ServiceProviderDashboard/ProviderHome";
import BookingRequests from "./components/ServiceProviderDashboard/BookingRequests";
import AvailabilityCalendar from "./components/ServiceProviderDashboard/AvailabilityCalendar";
import MyServices from "./components/ServiceProviderDashboard/Myservices";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/payment" element={<Payment />} />

      {/* Customer Dashboard */}
      <Route path="/CustomerHome" element={<Customerhome />} />
      <Route path="/BrowseServices" element={<BrowseServices />} />
      <Route path="/MyBookings" element={<EventConnectBookings />} />
      <Route path="/Messages" element={<EventConnectMessages />} />
      <Route path="/MyProfile" element={<EventConnectProfile />} />
      <Route path="/PaymentsBudget" element={<PaymentsBudget />} />
      <Route path="/MyReviews" element={<MyReviews />} />

      {/* Provider and admin dashboards */}
      <Route path="/ProviderDashboard" element={<ProviderDashboard />} />
      <Route path="/ProviderHome" element={<ProviderHome />} />
      <Route path="/MyServices" element={<MyServices />} />
      <Route path="/BookingRequests" element={<BookingRequests />} />
      <Route path="/AvailabilityCalendar" element={<AvailabilityCalendar />} />
      <Route path="/AdminDashboard" element={<AdminDashboard />} />
    </Routes>
  );
}

export default App;
