import { Link, useNavigate } from "react-router-dom";
import ClientSidebar from "./ClientSidebar";
import "./ClientDashboardPages.css";

const budgetEntries = [
  { name: "Grand Pavilion Venue", category: "Venue", amount: 9500, status: "Deposit paid" },
  { name: "Artisan Catering & Bar", category: "Catering", amount: 5900, status: "Quote approved" },
  { name: "Floral & Decor", category: "Decor", amount: 3050, status: "Deposit paid" },
];

const reviews = [
  { vendor: "Grand Ballroom", date: "October 19, 2025", rating: 5, text: "Exquisite acoustics and a wonderful team. Our guests loved the evening." },
  { vendor: "Lumière Lens & Cinema", date: "September 28, 2025", rating: 5, text: "Beautiful photography and thoughtful coverage from start to finish." },
  { vendor: "Artisan Gourmet Catering", date: "August 20, 2025", rating: 4, text: "A delicious menu and excellent service throughout the event." },
];

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "/login";
}

function PageShell({ title, description, children }) {
  const navigate = useNavigate();

  return (
    <div className="client-extra-app">
      <ClientSidebar
        onHelp={() => navigate("/Messages")}
        onLogout={logout}
      />
      <main className="client-extra-main">
        <header className="client-extra-topbar">
          <label>
            <span aria-hidden="true">⌕</span>
            <input aria-label="Search dashboard" placeholder="Search services, bookings, vendors..." />
          </label>
          <div className="client-extra-user">
            <span className="client-extra-avatar">A</span>
            <span><strong>Alex Johnson</strong><small>Private Host</small></span>
            <b>VIP</b>
          </div>
        </header>
        <section className="client-extra-content">
          <div className="client-extra-heading">
            <span>CLIENT DASHBOARD</span>
            <h1>{title}</h1>
            <p>{description}</p>
          </div>
          {children}
        </section>
      </main>
    </div>
  );
}

export function PaymentsBudget() {
  const total = budgetEntries.reduce((sum, entry) => sum + entry.amount, 0);
  const budget = 25000;

  return (
    <PageShell
      title="Payments & Budget"
      description="Track event spending, vendor payments, and your remaining budget."
    >
      <section className="client-extra-summary">
        <article><small>TOTAL EVENT BUDGET</small><strong>${budget.toLocaleString("en-US")}</strong><span>Gala Dinner · October 2025</span></article>
        <article><small>ALLOCATED</small><strong>${total.toLocaleString("en-US")}</strong><span>{Math.round((total / budget) * 100)}% of your budget</span></article>
        <article><small>REMAINING</small><strong>${(budget - total).toLocaleString("en-US")}</strong><span>Available for upcoming services</span></article>
      </section>
      <section className="client-extra-card">
        <div className="client-extra-card-heading"><div><h2>Budget breakdown</h2><p>Current vendor estimates and payments.</p></div><Link to="/MyBookings">View bookings</Link></div>
        <div className="client-extra-table">
          <div className="client-extra-table-row client-extra-table-head"><span>VENDOR / SERVICE</span><span>CATEGORY</span><span>AMOUNT</span><span>PAYMENT STATUS</span></div>
          {budgetEntries.map((entry) => (
            <div className="client-extra-table-row" key={entry.name}>
              <strong>{entry.name}</strong><span>{entry.category}</span><b>${entry.amount.toLocaleString("en-US")}</b><span className="client-extra-status">{entry.status}</span>
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  );
}

export function MyReviews() {
  return (
    <PageShell
      title="My Reviews"
      description="Your feedback for the event professionals who helped create your celebrations."
    >
      <section className="client-extra-summary">
        <article><small>REVIEWS SHARED</small><strong>{reviews.length}</strong><span>Thank you for supporting local artisans</span></article>
        <article><small>AVERAGE RATING</small><strong>4.7 / 5</strong><span>Your providers appreciate your feedback</span></article>
        <article><small>AWAITING REVIEW</small><strong>2</strong><span>Completed bookings ready for feedback</span></article>
      </section>
      <section className="client-extra-card">
        <div className="client-extra-card-heading"><div><h2>Reviews you have shared</h2><p>Feedback from your completed bookings.</p></div></div>
        <div className="client-extra-reviews">
          {reviews.map((review) => (
            <article key={review.vendor}>
              <div className="client-extra-review-heading"><div><h3>{review.vendor}</h3><small>{review.date}</small></div><span aria-label={`${review.rating} out of 5 stars`}>{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</span></div>
              <p>{review.text}</p>
            </article>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
