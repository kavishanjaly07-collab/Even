import React, { useMemo, useState } from "react";
import "./EventConnectBookings.css";
import ClientSidebar from "./ClientSidebar";

const initialBookings = [
  {
    id: "EC-84920",
    title: "Seraphina & David's Gala Dinner",
    category: "Photography & Film",
    vendor: "Lumière Lens & Cinema",
    avatar: "📸",
    status: "CONFIRMED",
    statusType: "confirmed",
    dateLabel: "DATE & TIME",
    date: "Oct 24, 2025 • 6:30 PM",
    location: "Grand Pavilion, West",
    budget: "$1,800 Paid in Full",
    progress: 100,
    progressLabel: "100% Deposit Cleared",
    note: "Request Adjustments",
    actions: ["Request Adjustments", "Contact Provider", "View Itinerary"],
    filter: "confirmed",
  },
  {
    id: "EC-84918",
    title: "Apex Tech Annual Summit",
    category: "Audio / Visual Production",
    vendor: "SoundWave AV & Staging",
    avatar: "🎤",
    status: "CONFIRMED",
    statusType: "confirmed",
    dateLabel: "DATE & TIME",
    date: "Nov 2, 2025 • 9:00 AM",
    location: "Metropolitan Convention Center",
    budget: "$4,200 Paid in Full",
    progress: 100,
    progressLabel: "50% Deposit Cleared",
    note: "Stage rider & layout approved",
    actions: ["Contact Provider", "View Details"],
    filter: "confirmed",
  },
  {
    id: "EC-84916",
    title: "Private Rooftop Birthday Soirée",
    category: "Floral & Space Design",
    vendor: "Velvet Bloom Floral & Décor",
    avatar: "🌷",
    status: "PENDING VENDOR APPROVAL",
    statusType: "pending",
    dateLabel: "TARGET DATE",
    date: "Dec 05, 2025 • 7:00 PM",
    location: "Skyline Terrace 34",
    budget: "$2,200 Quote Pending",
    progress: 0,
    progressLabel: "Vendor requested 24h to finalize exotic stem sourcing",
    actions: ["Cancel Inquiry", "Modify Request", "Review Proposal"],
    filter: "pending",
  },
  {
    id: "EC-83980",
    title: "Summer Executive Retreat Dinner",
    category: "Private Catering & Sommelier",
    vendor: "Artisan Gourmet Catering",
    avatar: "🍽️",
    status: "COMPLETED",
    statusType: "completed",
    dateLabel: "DELIVERED ON",
    date: "Aug 18, 2025",
    location: "The Vineyard Estate",
    budget: "$3,450 (Closed)",
    progress: 100,
    progressLabel: "Rated 5.0 by Alex Johnson",
    actions: ["View Invoice", "Leave Review", "Rebook Provider"],
    filter: "completed",
  },
  {
    id: "EC-83910",
    title: "Emerald Charity Gala",
    category: "Live Acoustic Performance",
    vendor: "Opus String Quartet & Ensemble",
    avatar: "🎻",
    status: "COMPLETED",
    statusType: "completed",
    dateLabel: "DELIVERED ON",
    date: "Jun 14, 2025",
    location: "Royal Opera House",
    budget: "$1,200 Paid",
    progress: 100,
    progressLabel: "Repertoire selections saved to event vault",
    actions: ["View Receipt", "Book Again"],
    filter: "completed",
  },
];

const filters = [
  { id: "all", label: "All Bookings (12)" },
  { id: "confirmed", label: "Upcoming & Confirmed (3)" },
  { id: "pending", label: "Pending Approval (2)" },
  { id: "completed", label: "Completed" },
];

function Icon({ children }) {
  return <span className="eb-icon" aria-hidden="true">{children}</span>;
}

function BookingCard({ booking, onAction }) {
  return (
    <article className="eb-booking-card">
      <div className="eb-booking-top">
        <div className={`eb-vendor-avatar eb-avatar-${booking.statusType}`}>{booking.avatar}</div>
        <div className="eb-booking-title">
          <div className="eb-booking-meta"><span>{booking.id}</span><i>•</i>{booking.category}</div>
          <h3>{booking.title}</h3>
          <div className="eb-vendor-name"><span>✦</span>{booking.vendor}</div>
        </div>
        <span className={`eb-status eb-status-${booking.statusType}`}>
          <i />{booking.status}
        </span>
      </div>

      <div className="eb-details-grid">
        <div className="eb-detail">
          <span className="eb-detail-icon">▣</span>
          <div><small>{booking.dateLabel}</small><strong>{booking.date}</strong></div>
        </div>
        <div className="eb-detail">
          <span className="eb-detail-icon">⌖</span>
          <div><small>LOCATION</small><strong>{booking.location}</strong></div>
        </div>
        <div className="eb-detail">
          <span className="eb-detail-icon">▤</span>
          <div><small>{booking.statusType === "pending" ? "PROPOSED COST" : booking.statusType === "completed" ? "SETTLEMENT AMOUNT" : "EST. / PAID"}</small><strong>{booking.budget}</strong></div>
        </div>
      </div>

      {booking.statusType === "confirmed" && (
        <div className="eb-progress-wrap">
          <div className="eb-progress-track"><span style={{ width: `${booking.progress}%` }} /></div>
          <span className="eb-progress-value">{booking.statusType === "confirmed" && booking.id === "EC-84918" ? "$2,100 of $4,200 total" : ""}</span>
        </div>
      )}

      <div className={`eb-booking-footer ${booking.statusType === "pending" ? "eb-pending-footer" : ""}`}>
        <div className="eb-booking-note">
          {booking.statusType === "completed" ? <span className="eb-note-star">☆</span> : booking.statusType === "pending" ? <span className="eb-note-warn">♜</span> : <span className="eb-note-check">✓</span>}
          {booking.progressLabel}
        </div>
        <div className="eb-booking-actions">
          {booking.actions.map((action, index) => (
            <button
              type="button"
              key={action}
              className={`eb-action-button ${action.includes("Review Proposal") || action.includes("View Itinerary") || action.includes("Book Again") || action.includes("Rebook") ? "is-strong" : index === 0 && booking.statusType === "pending" ? "is-danger" : ""}`}
              onClick={() => onAction(action, booking)}
            >
              {action}
            </button>
          ))}
        </div>
      </div>
    </article>
  );
}

export default function EventConnectBookings() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [calendarFilter, setCalendarFilter] = useState("2025 Calendar");
  const [showExport, setShowExport] = useState(false);
  const [notice, setNotice] = useState("");
  const [showNewBooking, setShowNewBooking] = useState(false);

  const filteredBookings = useMemo(() => initialBookings.filter((booking) => {
    const query = search.trim().toLowerCase();
    const matchesQuery = `${booking.title} ${booking.vendor} ${booking.id} ${booking.category}`.toLowerCase().includes(query);
    const matchesFilter = activeFilter === "all" || booking.filter === activeFilter;
    return matchesQuery && matchesFilter;
  }), [activeFilter, search]);

  function handleAction(action, booking) {
    setNotice(`${action} — ${booking.title}`);
    window.setTimeout(() => setNotice(""), 3200);
  }

  return (
    <div className="eb-page">
      <div className="eb-app">
        <ClientSidebar
          onHelp={() => setNotice("Connecting you with the concierge team…")}
          onLogout={() => setNotice("Log out is a demo action.")}
        />

        <main className="eb-main">
          <header className="eb-topbar">
            <label className="eb-global-search"><Icon>⌕</Icon><input placeholder="Search services, verified vendors, cakes, catering..." /><kbd>⌘ K</kbd></label>
            <div className="eb-top-actions">
              <button type="button" className="eb-top-icon" aria-label="Notifications">♧<i /></button>
              <button type="button" className="eb-top-icon" aria-label="Bookings">▣<i /></button>
              <div className="eb-user"><span className="eb-user-avatar">A</span><span className="eb-user-copy"><strong>Alex Johnson</strong><small>Private Host</small></span><span className="eb-vip">VIP</span></div>
            </div>
          </header>

          <section className="eb-page-heading">
            <div>
              <div className="eb-eyebrow">✦ CURATED RESERVATION LEDGER</div>
              <h1>My Bookings</h1>
              <p>Track, manage, and coordinate your upcoming and past event services reservations with private atelier concierge access.</p>
            </div>
            <div className="eb-summary-cards">
              <div className="eb-summary-card"><span className="eb-summary-icon green">▣</span><div><small>CONFIRMED</small><strong>3 Active</strong></div></div>
              <div className="eb-summary-card"><span className="eb-summary-icon gold">⌛</span><div><small>IN REVIEW</small><strong>2 Pending</strong></div></div>
              <button className="eb-export-button" type="button" onClick={() => setShowExport((value) => !value)}>⇩ Export<br />Ledger</button>
              {showExport && <div className="eb-export-menu"><button type="button" onClick={() => { setNotice("CSV export is a demo action."); setShowExport(false); }}>Export as CSV</button><button type="button" onClick={() => { setNotice("PDF export is a demo action."); setShowExport(false); }}>Export as PDF</button></div>}
            </div>
          </section>

          <section className="eb-content">
            <div className="eb-booking-toolbar">
              <div className="eb-filter-tabs">
                {filters.map((filter) => <button type="button" key={filter.id} className={activeFilter === filter.id ? "is-selected" : ""} onClick={() => setActiveFilter(filter.id)}>{filter.label}</button>)}
              </div>
              <label className="eb-booking-search"><Icon>⌕</Icon><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search provider or event..." /></label>
              <select className="eb-calendar-select" value={calendarFilter} onChange={(event) => setCalendarFilter(event.target.value)} aria-label="Calendar range">
                <option>2025 Calendar</option><option>2026 Calendar</option><option>All Dates</option>
              </select>
              <button className="eb-new-booking" type="button" onClick={() => setShowNewBooking(true)}>+ New Booking</button>
            </div>

            <div className="eb-layout">
              <section className="eb-bookings-list">
                {filteredBookings.map((booking) => <BookingCard key={booking.id} booking={booking} onAction={handleAction} />)}
                {filteredBookings.length === 0 && <div className="eb-no-results">No bookings match your search.</div>}
              </section>

              <aside className="eb-right-column">
                <section className="eb-concierge-card">
                  <div className="eb-concierge-heading"><span className="eb-concierge-icon">♜</span><div><h2>Booking Concierge</h2><small>DEDICATED SERVICE</small></div></div>
                  <p>Need custom scheduling buffers, vendor insurance riders, or other milestone billing support? Submit a request.</p>
                  <div className="eb-concierge-feature"><span>✧</span><div><strong>Vendor Guarantee</strong><small>All partner services providers are vetted & insured, backed by service certificates.</small></div></div>
                  <div className="eb-concierge-feature"><span>♧</span><div><strong>48-Hour Grace Period</strong><small>Modify your headcount and schedule windows with zero penalty.</small></div></div>
                  <div className="eb-concierge-feature"><span>♙</span><div><strong>Milestone Escrow</strong><small>Final balance payouts release only after service sign-off.</small></div></div>
                  <button type="button" className="eb-concierge-call" onClick={() => setNotice("Concierge call requested.")}>☎ Request Concierge Call</button>
                  <button type="button" className="eb-download" onClick={() => setNotice("Receipt download is a demo action.")}>Download All Receipts (ZIP)</button>
                </section>

                <section className="eb-timeline-card">
                  <div className="eb-timeline-title"><h2>Coordination Timeline</h2><span>Q4<br />2025</span></div>
                  {[
                    ["OCT 22, 2025", "Gala Dinner • Photography Briefing", "Grand Pavilion West Hall", "green"],
                    ["NOV 02, 2025", "Apex Tech Summit • Balance Due", "$2,100 Auto-settle in Escrow", "gold"],
                    ["DEC 05, 2025", "Rooftop Birthday Soirée", "Awaiting final proposal confirmation", "purple"],
                  ].map(([date, title, detail, color]) => <div className="eb-timeline-item" key={date}><span className={`eb-timeline-dot ${color}`} /><small>{date}</small><strong>{title}</strong><p>{detail}</p></div>)}
                </section>
              </aside>
            </div>
          </section>
        </main>

        {showNewBooking && <div className="eb-modal-backdrop" onClick={() => setShowNewBooking(false)} role="presentation">
          <form className="eb-modal" onSubmit={(event) => { event.preventDefault(); setShowNewBooking(false); setNotice("Your new booking request has been saved in this demo."); }} onClick={(event) => event.stopPropagation()}>
            <button className="eb-modal-close" type="button" onClick={() => setShowNewBooking(false)}>×</button>
            <div className="eb-eyebrow">CURATED RESERVATION LEDGER</div><h2>Create a booking request</h2><p>Share the essentials and your concierge can coordinate the details.</p>
            <label>Event name<input required placeholder="e.g. Anniversary dinner" /></label>
            <label>Service type<select defaultValue="Photography & Film"><option>Photography & Film</option><option>Audio / Visual Production</option><option>Floral & Space Design</option><option>Private Catering</option><option>Live Performance</option></select></label>
            <label>Target date<input type="date" required /></label>
            <label>Notes<textarea rows="3" placeholder="Tell us about your event..." /></label>
            <button type="submit" className="eb-new-booking">Submit Booking Request</button>
          </form>
        </div>}
        {notice && <div className="eb-toast" role="status">{notice}<button type="button" onClick={() => setNotice("")}>×</button></div>}
      </div>
    </div>
  );
}
