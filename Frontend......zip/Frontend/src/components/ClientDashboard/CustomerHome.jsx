import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./CustomerHome.css";
import ClientSidebar from "./ClientSidebar";


// ---------- DATA (SAMPLE TEXT: replace with your real text / backend data) ----------
// Put photos in "public/home" and change the image paths, or leave them empty.
const stats = [
  { icon: "📖", label: "TOTAL BOOKINGS", value: "12", pill: "+2 this mo", css: "ok" },
  { icon: "🎉", label: "UPCOMING EVENTS", value: "3", pill: "Next: Oct 24", css: "gold" },
  { icon: "💬", label: "PENDING QUOTES", value: "2", pill: "Awaiting Vendor", css: "purple" },
  { icon: "✅", label: "COMPLETED EVENTS", value: "7", pill: "100% Reviewed", css: "ok" },
];

const mainEvent = {
  image: "/home/gala.jpg",
  badges: ["CONFIRMED", "GALA & BANQUET"],
  countdown: "In 4 Days",
  eyebrow: "SIGNATURE HOST MILESTONES",
  title: "Seraphina & David's Gala Dinner",
  date: "Oct 24 • 6:30 PM",
  venue: "Grand Pavilion, West Hills",
  guests: "140 Guests RSVP'd",
  vendors: ["LM", "DF", "AM", "+2"],
  vendorText: "Lumière Floral & 3 others",
};

const smallEvents = [
  { tag: "Deposit Paid • $4,200", tagCss: "gold", date: "Nov 12, 2025", title: "Apex Annual Tech Summit Dinner", text: "Valet Catering & SoundWave AV Systems booked.", foot: "Setup at 2:00 PM" },
  { tag: "Confirmed • 85 Guests", tagCss: "ok", date: "Dec 09, 2025", title: "Private Rooftop Birthday Soirée", text: "Midnight Magic Lighting & Signature Cocktails.", foot: "Skyline Terrace 34" },
];

const providers = [
  { image: "/home/pavilion.jpg", badge: "15% Off Autumn", badgeCss: "gold", type: "LUXURY VENUE", name: "The Grand Pavilion & Gardens", rating: "4.9", reviews: 138, priceLabel: "Starts at", price: "$2,800", button: "Request Quote" },
  { image: "/home/catering.jpg", badge: "Free Tasting", badgeCss: "ok", type: "CATERING & MIXOLOGY", name: "Artisan Gourmet Catering", rating: "4.8", reviews: 90, priceLabel: "Pricing", price: "$65/guest", button: "View Menu" },
  { image: "/home/quartet.jpg", badge: "Popular", badgeCss: "purple", type: "LIVE MUSIC & ENSEMBLE", name: "Opus String Quartet & Band", rating: "5.0", reviews: 47, priceLabel: "Starts at", price: "$1,200", button: "Check Dates" },
];

const TARGET = 25000;
const budgetItems = [
  { name: "Grand Pavilion Venue", amount: 9500, color: "#7b2fa0" },
  { name: "Artisan Catering & Bar", amount: 5900, color: "#eab308" },
  { name: "Floral & Decor (Lumière)", amount: 3050, color: "#3b0a52" },
];

const activity = [
  { icon: "✔", title: "Booking confirmed with Lumière Floral", text: "3 hours ago • Table centerpieces locked in" },
  { icon: "💳", title: "Invoice paid: $1,450", text: "Yesterday • SoundWave AV deposit cleared" },
  { icon: "📄", title: "Contract inquiry sent", text: "2 days ago • Chef Julian's tasting menu" },
  { icon: "★", title: "Review submitted for Grand Ballroom", text: "5 days ago • Rated 5.0 ★ \"Exquisite acoustics\"" },
];

// ---------- HELPERS ----------
const usd = (n) => "$" + n.toLocaleString("en-US");

function getStoredUser() {
  try { return JSON.parse(localStorage.getItem("user")); } catch { return null; }
}

// A box that shows a photo, or a purple gradient if there is no photo yet
const photo = (url) => ({ backgroundImage: `url(${url})` });

// ---------- MAIN COMPONENT ----------
export default function CustomerHome() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const user = getStoredUser();
  const name = user ? user.username : "Alex";

  // Budget maths for the donut
  const spent = budgetItems.reduce((sum, item) => sum + item.amount, 0);
  const percent = Math.round((spent / TARGET) * 100);
  const R = 40, C = 2 * Math.PI * R;

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
  }

  return (
    <div className="ch">
      <ClientSidebar onHelp={() => navigate("/Messages")} onLogout={logout} />

      {/* ================= MAIN ================= */}
      <div className="ch-main">
        <header className="ch-top">
          <input className="ch-search" placeholder="🔍 Search bespoke styling, verified vendors, cakes, catering..."
            value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="ch-top-right">
            <button className="ch-icon" aria-label="Notifications">🔔<i></i></button>
            <button className="ch-icon" aria-label="Messages">💬<i></i></button>
            <div className="ch-profile">
              <span className="ch-avatar">{name.charAt(0).toUpperCase()}</span>
              <div><strong>{name} <b className="ch-vip">VIP</b></strong><small>Private Host</small></div>
            </div>
          </div>
        </header>

        <main className="ch-content">
          {/* ----- Welcome banner ----- */}
          <section className="ch-welcome">
            <div>
              <span className="ch-pill white">NEXT MILESTONE EVENT • Seraphina & David's Gala in 4 days</span>
              <h1>Welcome back, {name}!</h1>
              <p>Let's make your next event unforgettable. You have <b>3 upcoming events</b> scheduled this month.</p>
            </div>
            <div className="ch-welcome-buttons">
              <Link to="/BrowseServices" className="ch-btn gold">✨ Browse Services</Link>
              <Link to="/MyBookings" className="ch-text-link">📅 View My Bookings</Link>
            </div>
          </section>

          {/* ----- Stats ----- */}
          <section className="ch-stats">
            {stats.map((s) => (
              <div className="ch-card ch-stat" key={s.label}>
                <div className="ch-stat-top"><small>{s.label}</small><span className="ch-icon-box">{s.icon}</span></div>
                <strong>{s.value}</strong>
                <span className={`ch-pill ${s.css}`}>{s.pill}</span>
              </div>
            ))}
          </section>

          <div className="ch-columns">
            {/* ============ LEFT ============ */}
            <div className="ch-stack">
              <div className="ch-head">
                <h2><i className="ch-bar"></i>Upcoming Celebrations</h2>
                <a href="#" className="ch-link">View All (3) →</a>
              </div>

              {/* Featured event */}
              <article className="ch-card ch-event">
                <div className="ch-event-img" style={photo(mainEvent.image)}>
                  <div className="ch-event-badges">
                    {mainEvent.badges.map((b, i) => <span key={b} className={`ch-pill ${i === 0 ? "ok" : "white"}`}>{b}</span>)}
                    <span className="ch-pill gold right">{mainEvent.countdown}</span>
                  </div>
                  <div className="ch-event-title">
                    <small>{mainEvent.eyebrow}</small>
                    <h3>{mainEvent.title}</h3>
                  </div>
                </div>

                <div className="ch-event-info">
                  <div><small>DATE & TIME</small><b>{mainEvent.date}</b></div>
                  <div><small>VENUE LOCATION</small><b>{mainEvent.venue}</b></div>
                  <div><small>ATTENDANCE</small><b>{mainEvent.guests}</b></div>
                </div>

                <div className="ch-event-foot">
                  <small>Confirmed Vendors:</small>
                  <div className="ch-avatars">
                    {mainEvent.vendors.map((v) => <span key={v}>{v}</span>)}
                  </div>
                  <small className="grow">{mainEvent.vendorText}</small>
                  <button className="ch-btn light small">Itinerary</button>
                  <button className="ch-btn dark small">Manage Event</button>
                </div>
              </article>

              {/* Two small events */}
              <div className="ch-two">
                {smallEvents.map((e) => (
                  <article className="ch-card ch-small-event" key={e.title}>
                    <div className="ch-small-top"><span className={`ch-pill ${e.tagCss}`}>{e.tag}</span><small>{e.date}</small></div>
                    <h4>{e.title}</h4>
                    <p>{e.text}</p>
                    <div className="ch-small-foot"><small>📍 {e.foot}</small><a href="#" className="ch-link">Details ›</a></div>
                  </article>
                ))}
              </div>

              {/* Providers */}
              <div className="ch-head">
                <h2><i className="ch-bar gold"></i>Curated Luxury Providers</h2>
                <small className="ch-muted">HANDPICKED FOR YOUR STYLE</small>
              </div>
              <div className="ch-providers">
                {providers.map((p) => (
                  <article className="ch-card ch-provider" key={p.name}>
                    <div className="ch-provider-img" style={photo(p.image)}>
                      <span className={`ch-pill ${p.badgeCss}`}>{p.badge}</span>
                    </div>
                    <div className="ch-provider-body">
                      <small className="ch-type">{p.type}</small>
                      <h4>{p.name}</h4>
                      <p className="ch-rating">★ <b>{p.rating}</b> <small>({p.reviews} reviews)</small></p>
                      <div className="ch-provider-foot">
                        <div><small>{p.priceLabel}</small><b>{p.price}</b></div>
                        <button className="ch-btn dark small">{p.button}</button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>

            {/* ============ RIGHT ============ */}
            <div className="ch-stack">
              {/* Budget tracker */}
              <section className="ch-card">
                <div className="ch-head tight">
                  <h3>Gala Budget Tracker</h3><span className="ch-pill purple">Oct 2025</span>
                </div>
                <div className="ch-donut-wrap">
                  <svg viewBox="0 0 100 100" className="ch-donut" role="img" aria-label={`${percent}% allocated`}>
                    <circle cx="50" cy="50" r={R} fill="none" stroke="#eee" strokeWidth="12" />
                    <circle cx="50" cy="50" r={R} fill="none" stroke="#7b2fa0" strokeWidth="12" strokeLinecap="round"
                      strokeDasharray={`${(percent / 100) * C} ${C}`} transform="rotate(-90 50 50)" />
                    <text x="50" y="55" textAnchor="middle" fontSize="16" fontWeight="700">{percent}%</text>
                  </svg>
                  <div>
                    <small>ALLOCATED SPENDING</small>
                    <strong>{usd(spent)}</strong>
                    <small>of {usd(TARGET)} Total Target</small>
                  </div>
                </div>
                <ul className="ch-legend">
                  {budgetItems.map((b) => (
                    <li key={b.name}><i style={{ background: b.color }}></i>{b.name}<b>{usd(b.amount)}</b></li>
                  ))}
                </ul>
                <button className="ch-btn outline full">Manage Full Budget →</button>
              </section>

              {/* Activity feed */}
              <section className="ch-card">
                <div className="ch-head tight"><h3>Activity Feed</h3><small className="ch-muted">Real-time</small></div>
                <ul className="ch-feed">
                  {activity.map((a) => (
                    <li key={a.title}>
                      <span className="ch-feed-icon">{a.icon}</span>
                      <div><b>{a.title}</b><small>{a.text}</small></div>
                    </li>
                  ))}
                </ul>
              </section>

              {/* Concierge card */}
              <section className="ch-concierge">
                <span className="ch-pill gold">ATELIER CONCIERGE #8</span>
                <h3>Need a Bespoke Event Planner?</h3>
                <p>Connect with our certified style team for full-service luxury coordination, vendor contracts, and on-the-day execution.</p>
                <button className="ch-btn gold full">💬 Chat with Concierge</button>
              </section>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}