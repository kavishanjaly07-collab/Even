import { useState } from "react";
import "./AdminDashboard.css";

// ---------- DATA (SAMPLE TEXT: replace with your real text / backend data) ----------
const menu = [
  { heading: "CURATED MANAGEMENT", items: ["Overview", "Events Portfolio", "Artisans & Venues", "Escrow & Milestones", "Concierge Direct"] },
  { heading: "GOVERNANCE & CONTROLS", items: ["Accreditation", "Contract Vault"] },
];

const kpis = [
  { icon: "👥", label: "TOTAL USERS", value: "12,480", note: "+4.2% last month" },
  { icon: "🎨", label: "ARTISANS", value: "842", note: "+28 this month" },
  { icon: "✔", label: "APPROVALS", value: "19", note: "Pending approval backlog", badge: "Active" },
  { icon: "📅", label: "BOOKINGS", value: "3,150", note: "+18.4% vs last month" },
  { icon: "✅", label: "FULFILLMENT", value: "2,890", note: "91.7% completed" },
  { icon: "🏦", label: "TREASURY", value: "48.6M", note: "RS held in escrow" },
];

// Chart data: bars = confirmed bookings, line = escrow fund velocity
const months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov"];
const bookingBars = [420, 510, 590, 560, 700, 780];
const escrowLine = [48, 55, 63, 60, 74, 86];

const categories = [
  { name: "Photography & Film", value: 38, color: "#3b0a52" },
  { name: "Floral & Decor", value: 27, color: "#eab308" },
  { name: "Catering & Banquets", value: 20, color: "#7b2fa0" },
  { name: "Music & Production", value: 15, color: "#cdb0e3" },
];

const firstQueue = [
  { id: 1, name: "Araliya Fine Portraits", tag: "Fine Signature", category: "Photography", city: "Colombo", time: "2h ago", docs: "BR + NIC", status: "pending" },
  { id: 2, name: "Kandy Royal Blossom Art", tag: "Heritage Craft", category: "Floral & Montage", city: "Kandy", time: "5h ago", docs: "Artisan Guild", status: "pending" },
  { id: 3, name: "Galle Fort Chamber Music", tag: "Orchestral", category: "Chamber Music", city: "Galle", time: "Yesterday", docs: "Music Board", status: "pending" },
  { id: 4, name: "Serendib Culinary Banquets", tag: "Gourmet Catering", category: "Catering", city: "Negombo", time: "Yesterday", docs: "Health Cert.", status: "pending" },
  { id: 5, name: "Meliawatt Lighting & Sound", tag: "Stage Production", category: "Production / AV", city: "Kandy", time: "2 days ago", docs: "Safety Cert.", status: "pending" },
];

const escrow = [
  { label: "Held in Escrow", amount: 48950000, note: "60% allocated volume", percent: 60 },
  { label: "Released This Month", amount: 14184000, note: "88% milestone clearance", percent: 88 },
  { label: "Disputed / In Review", amount: 820000, note: "1.3% of portfolio", percent: 13 },
];

const bookings = [
  { id: "EC-LK-8832", client: "Lady Chandni Silva", provider: "The Sovereign Lens", date: "Dec 22, 2026", amount: 750000, status: "Confirmed" },
  { id: "EC-LK-2035", client: "Dr. Rohan Jayasekara", provider: "Cinéma Petals & Silk", date: "Dec 14, 2026", amount: 485000, status: "Confirmed" },
  { id: "EC-LK-3834", client: "Thilini Wickramasinghe", provider: "Autumn Heritage", date: "Nov 30, 2026", amount: 320000, status: "In Escrow" },
  { id: "EC-LK-5834", client: "Dinesh Perera", provider: "Chinatown Grand Hall", date: "Feb 02, 2027", amount: 1300000, status: "Pending" },
  { id: "EC-LK-6120", client: "Ananya Mendis", provider: "Aaliya Gold String Quartet", date: "Nov 18, 2026", amount: 85000, status: "Released" },
];
const statusClass = { Confirmed: "ok", "In Escrow": "held", Pending: "wait", Released: "ok" };

const firstDisputes = [
  { id: 1, title: "Flight permit hold", by: "Dr. Rohan Jayasekara", text: "Drone permit delayed the aerial coverage for the ceremony.", amount: 85000 },
  { id: 2, title: "Late setup delivery", by: "Thilini Wickramasinghe", text: "Lighting rig arrived two hours after the agreed milestone.", amount: 110000 },
];

const pulse = [
  { title: "New Artisan Onboarded", text: "Kandy Royal Blossom Art joined the directory.", time: "2h ago" },
  { title: "Escrow Receipt Confirmed", text: "RS 485,000 deposit received for EC-LK-2035.", time: "4h ago" },
  { title: "5-Star Review Verified", text: "Published for The Sovereign Lens.", time: "1 day ago" },
];

// ---------- HELPERS ----------
const rs = (n) => "RS " + n.toLocaleString("en-US");

// Sketches the bar + line chart as an SVG picture
function VolumeChart() {
  const W = 560, H = 190, base = 160;
  const step = W / months.length;
  const maxBar = Math.max(...bookingBars);
  const maxLine = Math.max(...escrowLine);
  const points = escrowLine.map((v, i) => [step * i + step / 2, base - (v / maxLine) * 120]);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="ad-chart" role="img" aria-label="Bookings and escrow chart">
      {bookingBars.map((v, i) => {
        const h = (v / maxBar) * 130;
        return <rect key={i} x={step * i + step / 2 - 14} y={base - h} width="28" height={h} rx="5" fill="#3b0a52" />;
      })}
      <polyline points={points.map((p) => p.join(",")).join(" ")} fill="none" stroke="#eab308" strokeWidth="3" />
      {points.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="4.5" fill="#fff" stroke="#eab308" strokeWidth="2.5" />)}
      {months.map((m, i) => (
        <text key={m} x={step * i + step / 2} y={H - 8} textAnchor="middle" fontSize="12" fill="#777">{m}</text>
      ))}
    </svg>
  );
}

// Draws the donut chart from the categories list
function Donut() {
  const R = 40, C = 2 * Math.PI * R;
  let offset = 0;
  return (
    <svg viewBox="0 0 100 100" className="ad-donut" role="img" aria-label="Bookings by category">
      <g transform="rotate(-90 50 50)">
        {categories.map((c) => {
          const len = (c.value / 100) * C;
          const circle = (
            <circle key={c.name} cx="50" cy="50" r={R} fill="none" stroke={c.color} strokeWidth="14"
              strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} />
          );
          offset += len;
          return circle;
        })}
      </g>
      <text x="50" y="49" textAnchor="middle" fontSize="11" fontWeight="700" fontFamily="Playfair Display, serif">3,150</text>
      <text x="50" y="59" textAnchor="middle" fontSize="5" fill="#777">TOTAL ACTS</text>
    </svg>
  );
}

// ---------- MAIN COMPONENT ----------
export default function AdminDashboard() {
  const [page, setPage] = useState("Overview");
  const [suite, setSuite] = useState("Admin Suite");
  const [queue, setQueue] = useState(firstQueue);
  const [disputes, setDisputes] = useState(firstDisputes);

  const pendingCount = queue.filter((q) => q.status === "pending").length;

  function decide(id, status) {
    setQueue(queue.map((q) => (q.id === id ? { ...q, status } : q)));
  }
  function closeDispute(id) {
    setDisputes(disputes.filter((d) => d.id !== id));
  }

  return (
    <div className="ad">
      {/* ================= SIDEBAR ================= */}
      <aside className="ad-side">
        <div className="ad-brand">
          <span className="ad-logo">EC</span>
          <div><strong>Event Connect</strong><small>CURATOR ATELIER</small></div>
        </div>

        <div className="ad-suite">
          {["Client Suite", "Admin Suite"].map((s) => (
            <button key={s} className={suite === s ? "on" : ""} onClick={() => setSuite(s)}>{s}</button>
          ))}
        </div>

        {menu.map((g) => (
          <div className="ad-group" key={g.heading}>
            <h4>{g.heading}</h4>
            {g.items.map((item) => (
              <button key={item} className={page === item ? "on" : ""} onClick={() => setPage(item)}>{item}</button>
            ))}
          </div>
        ))}

        <button className="ad-settings">⚙ Platform Settings</button>
      </aside>

      {/* ================= MAIN ================= */}
      <div className="ad-main">
        <header className="ad-top">
          <span className="ad-context">CONTEXT: <b>Bordeaux & Colombo Estate Resort</b></span>
          <div className="ad-top-right">
            <button className="ad-bell" aria-label="Notifications">🔔<i></i></button>
            <div className="ad-profile">
              <span className="ad-avatar">A</span>
              <div><strong>Platform Admin</strong><small>SUPER ADMIN</small></div>
            </div>
          </div>
        </header>

        <main className="ad-content">
          {/* ----- Title ----- */}
          <div className="ad-title">
            <div>
              <span className="ad-eyebrow">ADMINISTRATIVE CONTROL ENGINE</span>
              <h1>Platform Overview</h1>
              <p>Real-time telemetry across all verified event artisans, escrow liquidity reserve, and milestone engagements.</p>
            </div>
            <div className="ad-title-right">
              <select><option>Last 30 Days</option><option>Last 7 Days</option><option>Last 90 Days</option></select>
              <button className="ad-btn dark">⬇ Export Report</button>
            </div>
          </div>

          {/* ----- KPI cards ----- */}
          <section className="ad-kpis">
            {kpis.map((k) => (
              <div className="ad-card ad-kpi" key={k.label}>
                <div className="ad-kpi-top">
                  <small>{k.label}</small><span className="ad-icon">{k.icon}</span>
                </div>
                <strong>{k.value}</strong>
                <span className="ad-note">{k.badge && <b className="ad-pill gold">{k.badge}</b>} {k.note}</span>
              </div>
            ))}
          </section>

          {/* ----- Charts ----- */}
          <div className="ad-grid-chart">
            <section className="ad-card">
              <div className="ad-head">
                <div>
                  <h3>Volume & Escrow Liquidity</h3>
                  <p className="ad-sub">Dual determinist: confirmed bookings versus escrow fund velocity.</p>
                </div>
                <div className="ad-big">
                  <strong>RS 63,820,000</strong>
                  <small>+12.4% vs last period</small>
                </div>
              </div>
              <VolumeChart />
              <div className="ad-legend">
                <span><i style={{ background: "#3b0a52" }}></i>Confirmed Bookings</span>
                <span><i style={{ background: "#eab308" }}></i>Escrow Fund Velocity</span>
              </div>
            </section>

            <section className="ad-card">
              <h3>Category Share</h3>
              <p className="ad-sub">Distribution across published categories.</p>
              <Donut />
              <ul className="ad-cat-list">
                {categories.map((c) => (
                  <li key={c.name}><i style={{ background: c.color }}></i>{c.name}<b>{c.value}%</b></li>
                ))}
              </ul>
            </section>
          </div>

          {/* ----- Queue + Escrow ----- */}
          <div className="ad-grid-two">
            <section className="ad-card">
              <div className="ad-head">
                <div>
                  <h3>Provider Verification Queue <span className="ad-pill gold">{pendingCount} Pending Review</span></h3>
                  <p className="ad-sub">Strict compliance checks for Sri Lankan artisans, portfolios and credentials.</p>
                </div>
                <a href="#" className="ad-link">View All Queue</a>
              </div>

              <div className="ad-table-wrap">
                <table>
                  <thead>
                    <tr><th>STUDIO / ARTISAN</th><th>CATEGORY</th><th>CITY</th><th>SUBMITTED</th><th>CREDENTIALS</th><th>ACTIONS</th></tr>
                  </thead>
                  <tbody>
                    {queue.map((q) => (
                      <tr key={q.id}>
                        <td><div className="ad-who"><span>{q.name.charAt(0)}</span><div><b>{q.name}</b><small>{q.tag}</small></div></div></td>
                        <td>{q.category}</td>
                        <td>{q.city}</td>
                        <td>{q.time}</td>
                        <td><span className="ad-pill purple">{q.docs}</span></td>
                        <td>
                          {q.status === "pending" ? (
                            <div className="ad-actions">
                              <button className="ad-btn dark small" onClick={() => decide(q.id, "approved")}>Approve</button>
                              <button className="ad-btn outline small" onClick={() => decide(q.id, "rejected")}>Reject</button>
                            </div>
                          ) : (
                            <span className={`ad-pill ${q.status === "approved" ? "ok" : "no"}`}>
                              {q.status === "approved" ? "Approved ✅" : "Rejected"}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="ad-card">
              <h3>Escrow Treasury Health</h3>
              <p className="ad-sub">Automated milestone release and protection.</p>
              {escrow.map((e) => (
                <div className="ad-escrow" key={e.label}>
                  <div className="ad-escrow-row"><span>{e.label}</span><b>{rs(e.amount)}</b></div>
                  <div className="ad-bar"><div style={{ width: `${e.percent}%` }}></div></div>
                  <small>{e.note}</small>
                </div>
              ))}
              <div className="ad-audit"><span>Current audit status</span><b className="ad-pill ok">100% Secure</b></div>
              <a href="#" className="ad-link">View 8,142 Active Escrows →</a>
            </section>
          </div>

          {/* ----- Bookings + Disputes ----- */}
          <div className="ad-grid-two">
            <section className="ad-card">
              <div className="ad-head">
                <div>
                  <h3>Recent Platform Bookings</h3>
                  <p className="ad-sub">Live booking authorizations and settlement contracts.</p>
                </div>
                <button className="ad-btn light small">Filter Ledger</button>
              </div>
              <div className="ad-table-wrap">
                <table>
                  <thead>
                    <tr><th>ID</th><th>PATRON / CLIENT</th><th>ARTISAN / PROVIDER</th><th>DATE</th><th>AMOUNT</th><th>STATUS</th></tr>
                  </thead>
                  <tbody>
                    {bookings.map((b) => (
                      <tr key={b.id}>
                        <td><b>{b.id}</b></td><td>{b.client}</td><td>{b.provider}</td><td>{b.date}</td>
                        <td>{rs(b.amount)}</td>
                        <td><span className={`ad-pill ${statusClass[b.status]}`}>{b.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <div className="ad-stack">
              <section className="ad-card">
                <div className="ad-head">
                  <h3>Dispute Reviews</h3>
                  <span className="ad-pill no">{disputes.length} Cases</span>
                </div>
                {disputes.length === 0 && <p className="ad-sub">No open disputes 🎉</p>}
                {disputes.map((d) => (
                  <div className="ad-dispute" key={d.id}>
                    <div className="ad-escrow-row"><b>{d.title}</b><span>{rs(d.amount)}</span></div>
                    <small>Reported by {d.by}</small>
                    <p>{d.text}</p>
                    <div className="ad-actions">
                      <button className="ad-btn outline small" onClick={() => closeDispute(d.id)}>Dismiss</button>
                      <button className="ad-btn dark small" onClick={() => closeDispute(d.id)}>Resolve</button>
                    </div>
                  </div>
                ))}
              </section>

              <section className="ad-card">
                <h3>Platform Pulse</h3>
                <ul className="ad-pulse">
                  {pulse.map((p) => (
                    <li key={p.title}>
                      <i></i>
                      <div><b>{p.title}</b><p>{p.text}</p><small>{p.time}</small></div>
                    </li>
                  ))}
                </ul>
              </section>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
