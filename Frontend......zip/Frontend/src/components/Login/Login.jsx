import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [message, setMessage] = useState("");

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    const username = form.username.trim();

    if (!username || !form.password.trim()) {
      setMessage("Please enter your user name and password.");
      return;
    }

    let storedUser = null;
    const storedUserValue = localStorage.getItem("user");
    if (storedUserValue) {
      try {
        storedUser = JSON.parse(storedUserValue);
      } catch {
        setMessage("Saved user data is invalid. Please register again.");
        return;
      }
    }

    const user = storedUser?.username === username
      ? storedUser
      : { username, role: "customer" };

    localStorage.setItem("user", JSON.stringify(user));
    localStorage.removeItem("token");
    setMessage(`Welcome back, ${username}!`);
    window.setTimeout(() => navigate("/CustomerHome"), 800);
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1>LOGIN</h1>

        <label htmlFor="username">User Name</label>
        <input
          id="username"
          name="username"
          type="text"
          value={form.username}
          onChange={handleChange}
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          name="password"
          type="password"
          value={form.password}
          onChange={handleChange}
        />

        <button type="submit" className="pill-btn">Login</button>

        {message && <p className="login-message" role="status">{message}</p>}

        <p className="no-account">If you don't have an account</p>

        <Link to="/register" className="pill-btn">Register</Link>
      </form>
    </div>
  );
}
