
import React, { useState } from "react";
import "./BookingRequests.css";

const bookings = [
  {
    id: "BEC-8420",
    initials: "SJ",
    client: "Sarah Johnson",
    event: "Wedding Photography",
    service: "Wedding Photography",
    date: "16 Nov 2026",
    time: "10:00 AM - 08:00 PM",
    amount: "85,000",
    status: "Pending",
    color: "pink",
    location: "Grand Pavilion Hotel, Colombo District",
    phone: "+94 77 123 4567",
  },
  {
    id: "BEC-8421",
    initials: "DP",
    client: "Daniel Perera",
    event: "Corporate Tech Summit",
    service: "Corporate Photography",
    date: "20 Nov 2026",
    time: "09:00 AM - 04:00 PM",
    amount: "45,000",
    status: "Pending",
    color: "yellow",
    location: "Colombo Conference Hall",
    phone: "+94 71 234 5678",
  },
  {
    id: "BEC-8422",
    initials: "HP",
    client: "Harper Fernando",
    event: "Birthday Celebration",
    service: "Event Photography",
    date: "22 Nov 2026",
    time: "06:00 PM - 10:00 PM",
    amount: "32,000",
    status: "Confirmed",
    color: "purple",
    location: "Kandy City Center",
    phone: "+94 76 345 6789",
  },
  {
    id: "BEC-8423",
    initials: "KR",
    client: "Kevin & Rachel",
    event: "Engagement Session",
    service: "Engagement Photography",
    date: "24 Nov 2026",
    time: "04:00 PM - 07:00 PM",
    amount: "28,000",
    status: "Completed",
    color: "pink",
    location: "Royal Garden, Kandy",
    phone: "+94 75 456 7890",
  },
  {
    id: "BEC-8424",
    initials: "JR",
    client: "Dr. Julian Ross",
    event: "Product Launch",
    service: "Corporate Event",
    date: "27 Nov 2026",
    time: "09:00 AM - 02:00 PM",
    amount: "65,000",
    status: "Pending",
    color: "purple",
    location: "Colombo Business Center",
    phone: "+94 77 567 8901",
  },
  {
    id: "BEC-8425",
    initials: "AM",
    client: "Amanda Silva",
    event: "Private Concert",
    service: "Event Photography",
    date: "01 Dec 2026",
    time: "05:00 PM - 11:00 PM",
    amount: "55,000",
    status: "Rejected",
    color: "yellow",
    location: "Nelum Pokuna, Colombo",
    phone: "+94 70 678 9012",
  },
];

const menuItems = [
  ["⌂", "Overview"],
  ["♧", "My Services"],
  ["▣", "Booking Requests"],
  ["▤", "Availability Calendar"],
  ["▧", "Earnings & Payments"],
  ["✉", "Messages"],
  ["☆", "Reviews & Ratings"],
  ["♙", "Subscription & Membership"],
  ["♧", "Notifications"],
  ["♙", "My Profile"],
  ["?", "Help & Support"],
  ["↪", "Logout"],
];

const stats = [
  { label: "NEW REQUESTS", value: "8", sub: "Requires action", icon: "▤", type: "purple" },
  { label: "AWAITING CONFIRMATION", value: "5", sub: "Guest pending", icon: "◷", type: "yellow" },
  { label: "PENDING APPROVAL", value: "24", sub: "Deposit received", icon: "◉", type: "green" },
  { label: "COMPLETED", value: "96", sub: "100% revenue", icon: "✓", type: "pink" },
  { label: "CANCELLED / CLOSED", value: "3", sub: "Archived", icon: "×", type: "red" },
];

const filters = [
  "All Bookings",
  "New Requests",
  "Pending / Awaiting",
  "Confirmed",
  "Completed",
  "Rejected",
];

function BookingRequests() {
  const [activeMenu, setActiveMenu] = useState("Booking Requests");
  const [activeFilter, setActiveFilter] = useState("All Bookings");
  const [selectedBooking, setSelectedBooking] = useState(bookings[0]);
  const [search, setSearch] = useState("");
  const [message, setMessage] = useState("");

  const filteredBookings = bookings.filter((booking) => {
    const matchesSearch =
      booking.client.toLowerCase().includes(search.toLowerCase()) ||
      booking.id.toLowerCase().includes(search.toLowerCase()) ||
      booking.event.toLowerCase().includes(search.toLowerCase());

    const matchesFilter =
      activeFilter === "All Bookings" ||
      (activeFilter === "New Requests" && booking.status === "Pending") ||
      (activeFilter === "Pending / Awaiting" && booking.status === "Pending") ||
      booking.status === activeFilter;

    return matchesSearch && matchesFilter;
  });

  const updateBooking = (status) => {
    setSelectedBooking((previous) => ({ ...previous, status }));
    setMessage(`Booking ${selectedBooking.id} ${status.toLowerCase()} successfully.`);
  };

  return (
    <div className="bc-dashboard">

      {/* SIDEBAR */}
      <aside className="bc-sidebar">
        <div className="bc-logo">
          <span className="bc-logo-icon">✦</span>
          <span>Event Connect</span>
        </div>

        <div className="bc-sidebar-caption">
          YOUR EVENT, PERFECTLY PLANNED
        </div>

        <nav className="bc-navigation">
          {menuItems.map(([icon, label]) => (
            <button
              key={label}
              className={`bc-nav-item ${
                activeMenu === label ? "active" : ""
              } ${label === "Logout" ? "logout" : ""}`}
              onClick={() => setActiveMenu(label)}
            >
              <span className="bc-nav-icon">{icon}</span>
              <span>{label}</span>

              {label === "Booking Requests" && (
                <span className="bc-nav-count">8</span>
              )}
              {label === "Messages" && (
                <span className="bc-message-dot">3</span>
              )}
              {label === "Subscription & Membership" && (
                <span className="bc-pro">PRO</span>
              )}
            </button>
          ))}
        </nav>

        <div className="bc-sidebar-help">
          <strong>ARTISAN CONCIERGE</strong>
          <p>Need support or assistance? We're here to help.</p>
          <button onClick={() => setMessage("Contact support selected.")}>
            ♡ Contact Desk
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="bc-main">

        {/* TOP BAR */}
        <header className="bc-topbar">
          <div className="bc-breadcrumb">
            <span>Home</span>
            <span>›</span>
            <strong>Booking Requests</strong>
          </div>

          <div className="bc-top-actions">
            <input
              className="bc-global-search"
              placeholder="Search bookings, services, clients..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

            <button className="bc-top-icon">🔔</button>
            <button className="bc-top-icon">✉</button>

            <div className="bc-user">
              <div>
                <strong>Lumina Events</strong>
                <small>Creative Manager</small>
              </div>
              <span className="bc-user-avatar">L</span>
            </div>
          </div>
        </header>

        {/* PAGE HEADING */}
        <section className="bc-heading">
          <div>
            <div className="bc-eyebrow">MANAGE YOUR BUSINESS</div>
            <h1>Booking Requests</h1>
            <p>
              Manage incoming bookings, review event details, and schedule
              verified requests with confidence.
            </p>
          </div>

          <div className="bc-heading-buttons">
            <button className="bc-outline-button" onClick={() => window.print()}>
              ♧ Export Booking Report
            </button>
            <button
              className="bc-primary-button"
              onClick={() => setMessage("Custom quotation selected.")}
            >
              + Custom Quotation
            </button>
          </div>
        </section>

        {/* STATISTICS */}
        <section className="bc-stats">
          {stats.map((stat) => (
            <div className="bc-stat-card" key={stat.label}>
              <div className="bc-stat-top">
                <span>{stat.label}</span>
                <span className={`bc-stat-icon ${stat.type}`}>
                  {stat.icon}
                </span>
              </div>
              <h2>{stat.value}</h2>
              <div className="bc-stat-bottom">
                <span className={`bc-stat-dot ${stat.type}`}></span>
                {stat.sub}
              </div>
            </div>
          ))}
        </section>

        {/* FILTER TABS */}
        <section className="bc-filter-section">
          <div className="bc-filter-tabs">
            {filters.map((filter, index) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`bc-filter-tab ${
                  activeFilter === filter ? "selected" : ""
                }`}
              >
                {filter}
                <span>{[156, 8, 5, 24, 96, 3][index]}</span>
              </button>
            ))}
          </div>

          <div className="bc-filter-tools">
            <button className="bc-filter-search">⌕</button>
            <select aria-label="Category">
              <option>All Categories</option>
              <option>Photography</option>
              <option>Videography</option>
              <option>Decoration</option>
            </select>
            <select aria-label="Date range">
              <option>Nov 1, 2026 - Nov 30, 2026</option>
              <option>December 2026</option>
            </select>
            <select aria-label="Budget">
              <option>Any Budget (LKR)</option>
              <option>Below 50,000</option>
              <option>50,000 - 100,000</option>
            </select>
            <button className="bc-free-filter">✦ Conflict-Free Only</button>
          </div>
        </section>

        {/* BOOKINGS AND DETAILS */}
        <section className="bc-content-grid">

          {/* BOOKINGS TABLE */}
          <div className="bc-booking-table">
            <div className="bc-table-header">
              <span>BOOKING ID</span>
              <span>HOST / CLIENT</span>
              <span>EVENT & SERVICE</span>
              <span>DATE & SCHEDULE</span>
            </div>

            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => (
                <button
                  className={`bc-booking-row ${
                    selectedBooking.id === booking.id ? "row-active" : ""
                  }`}
                  key={booking.id}
                  onClick={() => {
                    setSelectedBooking(booking);
                    setMessage("");
                  }}
                >
                  <div>
                    <strong>{booking.id}</strong>
                    <small>♙ REQUEST</small>
                  </div>

                  <div className="bc-client-cell">
                    <span className={`bc-avatar ${booking.color}`}>
                      {booking.initials}
                    </span>
                    <span>
                      <strong>{booking.client}</strong>
                      <small>Verified Client</small>
                    </span>
                  </div>

                  <div>
                    <strong>{booking.event}</strong>
                    <small>{booking.service}</small>
                  </div>

                  <div>
                    <strong>{booking.date}</strong>
                    <small>{booking.time}</small>
                    <span className={`bc-status ${booking.status.toLowerCase()}`}>
                      {booking.status}
                    </span>
                  </div>
                </button>
              ))
            ) : (
              <div className="bc-empty">
                No booking requests found.
              </div>
            )}

            <div className="bc-table-footer">
              Showing {filteredBookings.length} of {bookings.length} requests
              <div>
                <button>‹</button>
                <span>Page 1 of 23</span>
                <button>›</button>
              </div>
            </div>
          </div>

          {/* BOOKING DETAILS */}
          <aside className="bc-details-panel">
            <div className="bc-detail-heading">
              <div>
                <small>REQUEST OVERVIEW</small>
                <h2>#{selectedBooking.id}</h2>
              </div>
              <span className="bc-new-label">NEW REQUEST</span>
            </div>

            <div className="bc-response-box">
              <strong>◉ Received 2h ago</strong>
              <p>Client is awaiting your response within 24 hours.</p>
            </div>

            <div className="bc-conflict-box">
              <strong>✓ No Calendar Conflicts Detected</strong>
              <p>
                Your selected schedule is available. You can safely proceed
                with this booking.
              </p>
            </div>

            <div className="bc-client-detail">
              <div className="bc-client-detail-top">
                <span className="bc-avatar pink">
                  {selectedBooking.initials}
                </span>
                <div>
                  <strong>{selectedBooking.client}</strong>
                  <small>Verified Client</small>
                </div>
                <span className="bc-pro">GOLD</span>
              </div>

              <p>✉ {selectedBooking.client.toLowerCase().replaceAll(" ", ".")}@gmail.com</p>
              <p>☎ {selectedBooking.phone}</p>

              <button
                className="bc-message-button"
                onClick={() => setMessage("Message window opened.")}
              >
                ✉ Send Direct Message
              </button>
            </div>

            <div className="bc-detail-section">
              <h4>EVENT SPECIFICATIONS</h4>
              <div className="bc-detail-info">
                <small>EVENT TYPE</small>
                <strong>{selectedBooking.event}</strong>
                <small>ATTENDANCE</small>
                <strong>250 Guests</strong>
              </div>

              <div className="bc-detail-info vertical">
                <small>VENUE & LOCATION</small>
                <strong>{selectedBooking.location}</strong>
              </div>

              <div className="bc-detail-info vertical">
                <small>DATE & TIME</small>
                <strong>{selectedBooking.date}</strong>
                <strong>{selectedBooking.time}</strong>
              </div>
            </div>

            <div className="bc-detail-section">
              <h4>REQUEST INSTRUCTIONS</h4>
              <p className="bc-instructions">
                Professional event coverage required. Please confirm the
                schedule and availability before accepting this request.
              </p>
            </div>

            <div className="bc-price-box">
              <div>
                <span>Base Service Price</span>
                <strong>LKR {selectedBooking.amount}</strong>
              </div>
              <div>
                <span>Commission Deduction</span>
                <strong>LKR 0</strong>
              </div>
              <div>
                <span>Tax</span>
                <strong>LKR 0</strong>
              </div>
              <hr />
              <div className="bc-total">
                <strong>Total Amount</strong>
                <strong>LKR {selectedBooking.amount}</strong>
              </div>
            </div>

            <div className="bc-action-buttons">
              <button
                className="bc-accept-button"
                onClick={() => updateBooking("Confirmed")}
                disabled={selectedBooking.status === "Confirmed"}
              >
                ✓ Accept Booking Request
              </button>
              <div>
                <button
                  className="bc-counter-button"
                  onClick={() => setMessage("Counter quotation selected.")}
                >
                  ♧ Counter Request
                </button>
                <button
                  className="bc-decline-button"
                  onClick={() => updateBooking("Rejected")}
                  disabled={selectedBooking.status === "Rejected"}
                >
                  ⊗ Decline
                </button>
              </div>
            </div>

            {message && (
              <div className="bc-feedback">{message}</div>
            )}
          </aside>
        </section>

        {/* BOTTOM DASHBOARD */}
        <section className="bc-bottom-grid">

          {/* CALENDAR HEATMAP */}
          <div className="bc-heatmap-card">
            <div className="bc-bottom-heading">
              <div>
                <h3>Calendar Overview</h3>
                <p>November 2026 Schedule & Commitment Heatmap</p>
              </div>
              <span>View Calendar ↗</span>
            </div>

            <div className="bc-legend">
              <span><i className="booked"></i> Booked Event</span>
              <span><i className="pending"></i> Pending Request</span>
              <span><i className="available"></i> Available</span>
            </div>

            <div className="bc-heatmap">
              {Array.from({ length: 28 }, (_, i) => {
                const day = i + 1;
                const type =
                  [3, 9, 14, 22].includes(day)
                    ? "booked"
                    : [5, 11, 18, 25].includes(day)
                    ? "pending"
                    : "available";

                return (
                  <button
                    key={day}
                    className={`bc-day ${type}`}
                    title={`November ${day}`}
                  >
                    <small>{day}</small>
                    <span>{type === "booked" ? "●" : type === "pending" ? "◷" : "○"}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECURITY */}
          <div className="bc-security-card">
            <div className="bc-bottom-heading">
              <div>
                <h3>Security & Availability</h3>
                <p>Audit Trail (BEC-8420)</p>
              </div>
              <span>View All ↗</span>
            </div>

            <div className="bc-security-item">
              <span className="security-green">✓</span>
              <div>
                <strong>Inquiry Received</strong>
                <small>Today at 09:45 AM · Sarah Johnson</small>
              </div>
            </div>

            <div className="bc-security-item">
              <span className="security-green">✓</span>
              <div>
                <strong>Calendar Conflict Scan Passed</strong>
                <small>Today at 09:46 AM · No conflicts</small>
              </div>
            </div>

            <div className="bc-security-item">
              <span className="security-yellow">◷</span>
              <div>
                <strong>Awaiting Response</strong>
                <small>24-hour response window</small>
              </div>
            </div>
          </div>
        </section>

        <footer className="bc-footer">
          © 2026 Event Connect. All rights reserved.
        </footer>

      </main>
    </div>
  );
}

export default BookingRequests;
