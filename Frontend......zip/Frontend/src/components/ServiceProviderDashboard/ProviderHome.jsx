import { useState } from "react";
import "./ProviderHome.css";

// ---------- DATA (SAMPLE TEXT: replace with your real text / backend data) ----------
const menu = [
  "Overview", "My Services", "Booking Requests", "Availability Calendar", "Messages",
  "Reviews & Ratings", "Subscription & Membership", "Notifications", "My Profile", "Help & Support",
];

const stats = [
  { icon: "📖", label: "Total Bookings", value: "128" },
  { icon: "⏳", label: "Pending Requests", value: "8", css: "gold" },
  { icon: "🎉", label: "Upcoming Events", value: "12" },
  { icon: "💰", label: "Monthly Revenue", value: "LKR 185,000", small: true },
  { icon: "⭐", label: "Average Rating", value: "4.8" },
];

const months = ["May", "Jun", "Jul", "Aug", "Sep", "Oct"];
const revenue = [90, 120, 105, 150, 170, 185]; // in thousands of LKR

const revenueStats = [
  { label: "TOTAL REVENUE", value: "LKR 1,235,000" },
  { label: "AVG. BOOKING", value: "LKR 38,500" },
  { label: "SETTLEMENT RATE", value: "98.4%" },
  { label: "DISPUTE RATE", value: "0.0%" },
];

const breakdown = [
  { name: "Confirmed", value: 56, color: "#3b0a52" },
  { name: "Completed", value: 52, color: "#eab308" },
  { name: "Pending", value: 8, color: "#7b2fa0" },
  { name: "Cancelled", value: 12, color: "#d4c3e0" },
];

const firstRequests = [
  { id: 1, client: "Seraphina & David Sterling", event: "Gala Dinner • Oct 24", guests: 140, place: "Grand Pavilion", amount: 75000, status: "pending" },
  { id: 2, client: "Apex Innovations (Marcus Brody)", event: "Tech Summit • Nov 12", guests: 220, place: "Colombo City Hall", amount: 110000, status: "pending" },
  { id: 3, client: "Bona Vance & Family", event: "Birthday Soirée • Dec 09", guests: 85, place: "Skyline Terrace", amount: 45000, status: "pending" },
];

const firstReviews = [
  { id: 1, who: "Opus Symphony Society", stars: 5, text: "Exquisite floral work. The hall looked breathtaking from the first minute.", replied: false },
  { id: 2, who: "Summer Executive Retreat", stars: 4, text: "Professional team and on-time setup. Would book again.", replied: false },
];

const providerServices = [
  { title: "Wedding Photography", category: "Photography", price: "LKR 45,000", status: "Active", rating: "4.9" },
  { title: "Grand Wedding Decoration", category: "Decorations", price: "LKR 65,000", status: "Active", rating: "4.8" },
  { title: "Artisan Catering & Banquets", category: "Catering", price: "LKR 1,500 / guest", status: "Active", rating: "4.7" },
];

const initialMessages = [
  { from: "client", name: "Seraphina Sterling", text: "Could you confirm the floral setup time for our gala?", time: "10:42 AM" },
  { from: "provider", name: "You", text: "Certainly. Our team will arrive at 2:00 PM for setup.", time: "10:48 AM" },
  { from: "client", name: "Marcus Brody", text: "Thank you for sending the event photography package.", time: "Yesterday" },
];

const feed = [
  { text: "New booking request from Bona Vance & Family", time: "10 min ago" },
  { text: "Payment of LKR 45,000 released from escrow", time: "2 hours ago" },
  { text: "5-star review received from Opus Symphony Society", time: "Yesterday" },
  { text: "Calendar updated: Nov 24 blocked", time: "2 days ago" },
];

const events = [
  { id: "EC-1001", name: "Seraphina & David's Gala Dinner", type: "Gala Banquet", client: "Seraphina Sterling", date: "Oct 24, 2026 • 6:30 PM", place: "Grand Pavilion, West Hills", amount: 85000, status: "Confirmed" },
  { id: "EC-1002", name: "Apex Annual Tech Summit", type: "Corporate", client: "Marcus Brody", date: "Nov 12, 2026 • 2:00 PM", place: "Colombo City Hall", amount: 110000, status: "Confirmed" },
  { id: "EC-1003", name: "Rooftop Birthday Soirée", type: "Private Party", client: "Bona Vance", date: "Dec 09, 2026 • 8:00 PM", place: "Skyline Terrace 34", amount: 45000, status: "Pending" },
  { id: "EC-1004", name: "Winter Charity Benefit", type: "Fundraiser", client: "Lian Ross", date: "Dec 20, 2026 • 7:00 PM", place: "Galle Face Hotel", amount: 95000, status: "Confirmed" },
  { id: "EC-1005", name: "Heritage Wedding Reception", type: "Wedding", client: "Nuwan & Isuri", date: "Jan 15, 2027 • 5:00 PM", place: "Kandy Lake Club", amount: 130000, status: "Confirmed" },
];
const PAGE_SIZE = 4;

// ---------- HELPERS ----------
const lkr = (n) => "LKR " + n.toLocaleString("en-US");

function getStoredUser() {
  try { return JSON.parse(localStorage.getItem("user")); } catch { return null; }
}

// Draws the purple area + line chart from the revenue numbers
function RevenueChart() {
  const W = 520, H = 170, left = 10, base = 140;
  const step = (W - left * 2) / (revenue.length - 1);
  const max = Math.max(...revenue);
  const pts = revenue.map((v, i) => [left + step * i, base - (v / max) * 110]);
  const line = pts.map((p) => p.join(",")).join(" ");
  const area = `${left},${base} ${line} ${left + step * (revenue.length - 1)},${base}`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="ph-chart" role="img" aria-label="Monthly revenue">
      <defs>
        <linearGradient id="phFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7b2fa0" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#7b2fa0" stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={area} fill="url(#phFill)" />
      <polyline points={line} fill="none" stroke="#7b2fa0" strokeWidth="3" />
      {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="4" fill="#fff" stroke="#7b2fa0" strokeWidth="2.5" />)}
      {months.map((m, i) => (
        <text key={m} x={left + step * i} y={H - 6} textAnchor="middle" fontSize="11" fill="#777">{m}</text>
      ))}
    </svg>
  );
}

// ---------- MAIN COMPONENT ----------
export default function ProviderHome() {
  const [page, setPage] = useState("Overview");
  const [requests, setRequests] = useState(firstRequests);
  const [reviews, setReviews] = useState(firstReviews);
  const [filter, setFilter] = useState("All");
  const [tablePage, setTablePage] = useState(1);
  const [messages, setMessages] = useState(initialMessages);
  const [messageDraft, setMessageDraft] = useState("");
  const [notificationsRead, setNotificationsRead] = useState(false);

  const user = getStoredUser();
  const name = user?.username || "Lumière Events";

  const pendingCount = requests.filter((r) => r.status === "pending").length;

  function answer(id, status) {
    setRequests(requests.map((r) => (r.id === id ? { ...r, status } : r)));
  }
  function respond(id) {
    setReviews(reviews.map((r) => (r.id === id ? { ...r, replied: true } : r)));
  }

  // Table: filter, then split into pages
  const shown = events.filter((e) => filter === "All" || e.status === filter);
  const pages = Math.max(1, Math.ceil(shown.length / PAGE_SIZE));
  const rows = shown.slice((tablePage - 1) * PAGE_SIZE, tablePage * PAGE_SIZE);

  // Donut
  const total = breakdown.reduce((s, b) => s + b.value, 0);
  const R = 40, C = 2 * Math.PI * R;
  let offset = 0;

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
  }

  function sendMessage(event) {
    event.preventDefault();
    const text = messageDraft.trim();
    if (!text) return;
    setMessages((current) => [
      ...current,
      { from: "provider", name: "You", text, time: "Now" },
    ]);
    setMessageDraft("");
  }

  function renderPageContent() {
    const pageDescriptions = {
      "My Services": "Manage the services and packages visible to event clients.",
      "Booking Requests": "Review incoming requests and respond to clients.",
      "Availability Calendar": "Review upcoming events and manage your schedule.",
      Messages: "Keep client conversations and event details in one place.",
      "Reviews & Ratings": "Review client feedback and respond to your reviews.",
      "Subscription & Membership": "Review your provider membership and plan benefits.",
      Notifications: "Stay up to date with booking, payment, and review activity.",
      "My Profile": "Review the public profile and account details clients see.",
      "Help & Support": "Get assistance with your provider account and events.",
    };

    return (
      <>
        <div className="ph-page-heading">
          <div>
            <span className="ph-page-eyebrow">PROVIDER PORTAL</span>
            <h1>{page}</h1>
            <p>{pageDescriptions[page]}</p>
          </div>
          {page === "Notifications" && (
            <button className="ph-btn light" onClick={() => setNotificationsRead(true)}>
              Mark all as read
            </button>
          )}
        </div>

        {page === "My Services" && (
          <>
            <div className="ph-page-toolbar">
              <div><strong>{providerServices.length} listed services</strong><small>Active packages offered to clients</small></div>
              <span className="ph-pill ok">Provider profile verified</span>
            </div>
            <div className="ph-page-grid">
              {providerServices.map((service) => (
                <article className="ph-card ph-service-card" key={service.title}>
                  <span className="ph-service-icon">✦</span>
                  <span className="ph-page-eyebrow">{service.category}</span>
                  <h3>{service.title}</h3>
                  <div className="ph-service-details"><span>★ {service.rating}</span><b>{service.price}</b></div>
                  <span className="ph-pill ok">{service.status}</span>
                </article>
              ))}
            </div>
          </>
        )}

        {page === "Booking Requests" && (
          <section className="ph-card">
            <div className="ph-head">
              <div><h3>Incoming booking requests</h3><p className="ph-sub">{pendingCount} requests need a response.</p></div>
              <span className="ph-pill gold">{pendingCount} Pending</span>
            </div>
            {requests.map((request) => (
              <div className="ph-request" key={request.id}>
                <div className="ph-initials">{request.client.charAt(0)}</div>
                <div className="ph-request-body">
                  <div className="ph-row"><strong>{request.client}</strong><b>{lkr(request.amount)}</b></div>
                  <small>{request.event} · {request.guests} guests · {request.place}</small>
                  {request.status === "pending" ? (
                    <div className="ph-buttons">
                      <button className="ph-btn dark small" onClick={() => answer(request.id, "accepted")}>Accept Booking</button>
                      <button className="ph-btn light small" onClick={() => answer(request.id, "declined")}>Decline</button>
                    </div>
                  ) : (
                    <span className={`ph-pill ${request.status === "accepted" ? "ok" : "no"}`}>
                      {request.status === "accepted" ? "Accepted" : "Declined"}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </section>
        )}

        {page === "Availability Calendar" && (
          <div className="ph-grid-2">
            <section className="ph-card">
              <div className="ph-head"><div><h3>November 2026</h3><p className="ph-sub">Your upcoming confirmed and pending events.</p></div><span className="ph-pill purple">Monthly schedule</span></div>
              <div className="ph-calendar-days">{["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => <span key={day}>{day}</span>)}</div>
              <div className="ph-calendar-dates">
                {Array.from({ length: 30 }, (_, index) => {
                  const day = index + 1;
                  const isBooked = [7, 12, 14, 21, 28].includes(day);
                  return <span className={isBooked ? "booked" : ""} key={day}>{day}</span>;
                })}
              </div>
              <p className="ph-calendar-legend"><i /> Booked or reserved dates</p>
            </section>
            <section className="ph-card">
              <h3>Upcoming schedule</h3>
              <p className="ph-sub">Next events on your calendar.</p>
              <ul className="ph-page-list">
                {events.slice(0, 4).map((event) => (
                  <li key={event.id}><b>{event.name}</b><small>{event.date} · {event.place}</small><span className={`ph-pill ${event.status === "Confirmed" ? "ok" : "gold"}`}>{event.status}</span></li>
                ))}
              </ul>
            </section>
          </div>
        )}

        {page === "Messages" && (
          <section className="ph-card">
            <div className="ph-head"><div><h3>Client conversations</h3><p className="ph-sub">Recent messages from your event clients.</p></div></div>
            <div className="ph-message-list">
              {messages.map((message, index) => (
                <article className={`ph-message ${message.from === "provider" ? "sent" : ""}`} key={`${message.time}-${index}`}>
                  <div className="ph-row"><strong>{message.name}</strong><small>{message.time}</small></div>
                  <p>{message.text}</p>
                </article>
              ))}
            </div>
            <form className="ph-message-form" onSubmit={sendMessage}>
              <input aria-label="Write a message" value={messageDraft} onChange={(event) => setMessageDraft(event.target.value)} placeholder="Write a message to your clients..." />
              <button className="ph-btn dark" type="submit">Send message</button>
            </form>
          </section>
        )}

        {page === "Reviews & Ratings" && (
          <section className="ph-card">
            <div className="ph-head"><div><h3>Client reviews</h3><p className="ph-sub">Your average rating is 4.8 out of 5.</p></div><span className="ph-pill gold">★ 4.8 Average</span></div>
            {reviews.map((review) => (
              <article className="ph-review" key={review.id}>
                <div className="ph-row"><strong>{review.who}</strong><span className="ph-stars">{"★".repeat(review.stars)}{"☆".repeat(5 - review.stars)}</span></div>
                <p>{review.text}</p>
                {review.replied ? <small className="ph-ok">Response sent</small> : <button className="ph-link-btn" onClick={() => respond(review.id)}>Respond to review</button>}
              </article>
            ))}
          </section>
        )}

        {page === "Subscription & Membership" && (
          <div className="ph-grid-2">
            <section className="ph-card ph-membership-card">
              <span className="ph-pill gold">CURRENT MEMBERSHIP</span>
              <h2>Event Connect Pro</h2>
              <p>Get discovered by more clients and manage your event business with premium provider tools.</p>
              <strong className="ph-membership-price">LKR 12,500 <small>/ month</small></strong>
              <span className="ph-pill ok">Membership active</span>
            </section>
            <section className="ph-card">
              <h3>Your Pro benefits</h3>
              <ul className="ph-page-list">
                {["Priority placement in provider search", "Unlimited service listings", "Booking and calendar management", "Verified Pro profile badge", "Monthly performance insights"].map((benefit) => <li key={benefit}><b>{benefit}</b><span className="ph-ok">Included</span></li>)}
              </ul>
            </section>
          </div>
        )}

        {page === "Notifications" && (
          <section className="ph-card">
            <div className="ph-head"><div><h3>Recent activity</h3><p className="ph-sub">Booking and account updates.</p></div></div>
            <ul className="ph-page-list">
              {feed.map((item) => <li className={notificationsRead ? "read" : ""} key={item.text}><b>{item.text}</b><small>{item.time}</small>{!notificationsRead && <span className="ph-pill purple">New</span>}</li>)}
            </ul>
          </section>
        )}

        {page === "My Profile" && (
          <div className="ph-grid-2">
            <section className="ph-card">
              <div className="ph-profile-summary"><span className="ph-avatar large">{name.charAt(0).toUpperCase()}</span><div><h3>{name}</h3><p className="ph-sub">Verified Event Connect provider</p></div></div>
              <ul className="ph-page-list">
                <li><b>Account name</b><span>{name}</span></li>
                <li><b>Account email</b><span>{user?.email || "Not provided"}</span></li>
                <li><b>Provider status</b><span className="ph-pill ok">Verified</span></li>
              </ul>
            </section>
            <section className="ph-card">
              <h3>Public profile</h3>
              <p className="ph-sub">Your profile is visible to clients browsing event providers.</p>
              <div className="ph-profile-progress"><span style={{ width: "85%" }} /></div>
              <p className="ph-sub">Profile completion: 85%</p>
              <span className="ph-pill purple">Public profile</span>
            </section>
          </div>
        )}

        {page === "Help & Support" && (
          <div className="ph-grid-2">
            <section className="ph-card">
              <h3>How can we help?</h3>
              <p className="ph-sub">Find help with common provider tasks.</p>
              <ul className="ph-page-list">
                {["Managing your service listings", "Responding to booking requests", "Updating calendar availability", "Understanding payments and settlements"].map((topic) => <li key={topic}><b>{topic}</b><span className="ph-link">View guide →</span></li>)}
              </ul>
            </section>
            <section className="ph-card ph-support-card">
              <span className="ph-service-icon">✦</span>
              <h3>Atelier Concierge</h3>
              <p>Need help with an event or your provider account? Our support team is ready to assist.</p>
              <button className="ph-btn gold" onClick={() => setPage("Messages")}>Contact support</button>
              <small>Available every day · 9:00 AM–6:00 PM</small>
            </section>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="ph">
      {/* ================= SIDEBAR ================= */}
      <aside className="ph-side">
        <div className="ph-brand">
          <span className="ph-logo">✦</span>
          <div><strong>Event Connect</strong><small>PROVIDER PORTAL</small></div>
        </div>

        <nav className="ph-menu">
          {menu.map((item) => (
            <button
              key={item}
              type="button"
              className={page === item ? "on" : ""}
              aria-current={page === item ? "page" : undefined}
              onClick={() => setPage(item)}
            >
              {item}
            </button>
          ))}
        </nav>

        <div className="ph-help">
          <strong>Atelier Concierge</strong>
          <p>Need help growing your bookings?</p>
          <button className="ph-btn gold small" onClick={() => setPage("Help & Support")}>Contact Us</button>
        </div>
        <button className="ph-logout" onClick={logout}>↪ Logout</button>
      </aside>

      {/* ================= MAIN ================= */}
      <div className="ph-main">
        <header className="ph-top">
          <input className="ph-search" placeholder="🔍 Search bookings, clients, services..." />
          <div className="ph-top-right">
            <button className="ph-icon" aria-label="Notifications" onClick={() => setPage("Notifications")}>🔔<i></i></button>
            <div className="ph-profile">
              <span className="ph-avatar">{name.charAt(0).toUpperCase()}</span>
              <div><strong>{name}</strong><small>Verified Provider</small></div>
            </div>
          </div>
        </header>

        <main className="ph-content">
          {page === "Overview" ? (
            <>
          {/* ----- Welcome ----- */}
          <section className="ph-welcome">
            <div>
              <h1>Welcome back, {name}!</h1>
              <p><span className="ph-pill white">✔ Verified Pro</span> &nbsp; You have <b>{pendingCount} pending requests</b> waiting for your reply.</p>
            </div>
            <div className="ph-welcome-buttons">
              <button className="ph-btn gold" onClick={() => setPage("My Services")}>+ Add New Service</button>
              <button className="ph-btn glass" onClick={() => setPage("Availability Calendar")}>Open Calendar</button>
              <button className="ph-btn glass" onClick={() => setPage("Booking Requests")}>Manage Bookings</button>
            </div>
          </section>

          {/* ----- Stats ----- */}
          <section className="ph-stats">
            {stats.map((s) => (
              <div className="ph-card ph-stat" key={s.label}>
                <span className="ph-icon-box">{s.icon}</span>
                <small>{s.label}</small>
                <strong className={s.small ? "smaller" : ""}>
                  {s.label === "Pending Requests" ? pendingCount : s.value}
                </strong>
              </div>
            ))}
          </section>

          {/* ----- Analytics ----- */}
          <div className="ph-grid-2">
            <section className="ph-card">
              <div className="ph-head">
                <div><h3>Revenue Analytics</h3><p className="ph-sub">Earnings from confirmed and completed bookings.</p></div>
                <span className="ph-pill purple">Current</span>
              </div>
              <div className="ph-rev-stats">
                {revenueStats.map((r) => (
                  <div key={r.label}><small>{r.label}</small><b>{r.value}</b></div>
                ))}
              </div>
              <RevenueChart />
            </section>

            <section className="ph-card">
              <h3>Booking Breakdown</h3>
              <p className="ph-sub">Status of all your bookings.</p>
              <svg viewBox="0 0 100 100" className="ph-donut" role="img" aria-label="Booking breakdown">
                <g transform="rotate(-90 50 50)">
                  {breakdown.map((b) => {
                    const len = (b.value / total) * C;
                    const circle = <circle key={b.name} cx="50" cy="50" r={R} fill="none" stroke={b.color} strokeWidth="14"
                      strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} />;
                    offset += len;
                    return circle;
                  })}
                </g>
                <text x="50" y="50" textAnchor="middle" fontSize="14" fontWeight="700" fontFamily="Playfair Display, serif">{total}</text>
                <text x="50" y="60" textAnchor="middle" fontSize="5" fill="#777">TOTAL BOOKINGS</text>
              </svg>
              <ul className="ph-legend">
                {breakdown.map((b) => (
                  <li key={b.name}><i style={{ background: b.color }}></i>{b.name}<b>{b.value}</b></li>
                ))}
              </ul>
            </section>
          </div>

          {/* ----- Requests + Reviews + Feed ----- */}
          <div className="ph-grid-2">
            <section className="ph-card">
              <div className="ph-head">
                <div><h3>Recent Booking Requests</h3><p className="ph-sub">Respond quickly to win more bookings.</p></div>
                <span className="ph-pill gold">{pendingCount} Pending</span>
              </div>

              {requests.map((r) => (
                <div className="ph-request" key={r.id}>
                  <div className="ph-initials">{r.client.charAt(0)}</div>
                  <div className="ph-request-body">
                    <div className="ph-row"><strong>{r.client}</strong><b>{lkr(r.amount)}</b></div>
                    <small>{r.event} • {r.guests} guests • {r.place}</small>
                    {r.status === "pending" ? (
                      <div className="ph-buttons">
                        <button className="ph-btn dark small" onClick={() => answer(r.id, "accepted")}>Accept Booking</button>
                        <button className="ph-btn light small" onClick={() => answer(r.id, "declined")}>Decline</button>
                      </div>
                    ) : (
                      <span className={`ph-pill ${r.status === "accepted" ? "ok" : "no"}`}>
                        {r.status === "accepted" ? "Accepted ✅" : "Declined"}
                      </span>
                    )}
                  </div>
                </div>
              ))}
              <button type="button" className="ph-link center" onClick={() => setPage("Booking Requests")}>View All {pendingCount} Pending Inquiries →</button>
            </section>

            <div className="ph-stack">
              <section className="ph-card">
                <h3>Recent Reviews</h3>
                {reviews.map((r) => (
                  <div className="ph-review" key={r.id}>
                    <div className="ph-row"><strong>{r.who}</strong><span className="ph-stars">{"★".repeat(r.stars)}{"☆".repeat(5 - r.stars)}</span></div>
                    <p>{r.text}</p>
                    {r.replied ? <small className="ph-ok">Response sent ✅</small> : <button className="ph-link-btn" onClick={() => respond(r.id)}>Respond to review</button>}
                  </div>
                ))}
              </section>

              <section className="ph-card">
                <h3>Live Activity Feed</h3>
                <ul className="ph-feed">
                  {feed.map((f) => (
                    <li key={f.text}><i></i><div><b>{f.text}</b><small>{f.time}</small></div></li>
                  ))}
                </ul>
              </section>
            </div>
          </div>

          {/* ----- Upcoming confirmed events table ----- */}
          <section className="ph-card">
            <div className="ph-head">
              <div><h3>Upcoming Confirmed Events</h3><p className="ph-sub">Your schedule at a glance.</p></div>
              <button className="ph-btn light small">Export Schedule</button>
            </div>

            <div className="ph-filters">
              {["All", "Confirmed", "Pending"].map((f) => (
                <button key={f} className={filter === f ? "on" : ""} onClick={() => { setFilter(f); setTablePage(1); }}>{f}</button>
              ))}
              <small>({shown.length} events)</small>
            </div>

            <div className="ph-table-wrap">
              <table>
                <thead>
                  <tr><th>BOOKING ID</th><th>EVENT NAME & TYPE</th><th>CLIENT</th><th>DATE & TIME</th><th>LOCATION & VENUE</th><th>PACKAGE</th><th>STATUS</th></tr>
                </thead>
                <tbody>
                  {rows.map((e) => (
                    <tr key={e.id}>
                      <td><b>{e.id}</b></td>
                      <td><b>{e.name}</b><small className="block">{e.type}</small></td>
                      <td>{e.client}</td>
                      <td>{e.date}</td>
                      <td>{e.place}</td>
                      <td>{lkr(e.amount)}</td>
                      <td><span className={`ph-pill ${e.status === "Confirmed" ? "ok" : "gold"}`}>{e.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="ph-pager">
              <small>Showing {rows.length} of {shown.length} confirmed events</small>
              <div>
                <button onClick={() => setTablePage(Math.max(1, tablePage - 1))} disabled={tablePage === 1}>Previous</button>
                {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                  <button key={p} className={tablePage === p ? "on" : ""} onClick={() => setTablePage(p)}>{p}</button>
                ))}
                <button onClick={() => setTablePage(Math.min(pages, tablePage + 1))} disabled={tablePage === pages}>Next</button>
              </div>
            </div>
          </section>
            </>
          ) : renderPageContent()}
        </main>
      </div>
    </div>
  );
}
