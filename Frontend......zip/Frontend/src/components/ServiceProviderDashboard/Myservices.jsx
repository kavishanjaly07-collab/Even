import { useState } from "react";
import "./Myservices.css";

// ---------- DATA (SAMPLE TEXT: replace with your real text / backend data) ----------
// Put photos in "public/services" and change the image paths, or leave them as they are.
const menu = [
  { name: "Overview" },
  { name: "My Services" },
  { name: "Booking Requests", badge: "8", badgeCss: "gold" },
  { name: "Availability Calendar" },
  { name: "Earnings & Payments" },
  { name: "Messages", badge: "3", badgeCss: "gold" },
  { name: "Reviews & Ratings" },
  { name: "Subscription & Membership", badge: "PRO", badgeCss: "purple" },
  { name: "Notifications" },
  { name: "My Profile" },
  { name: "Help & Support" },
];

const firstServices = [
  { id: 1, category: "Photography", image: "/services/photo.jpg", status: "Active", rating: "4.9", reviews: 94, tag: "Next slot: This Weekend", title: "Wedding Photography", text: "Full-day two-shooter coverage, dual album delivery and a cinematic highlight reel.", price: 45000, unit: "Per Event Package" },
  { id: 2, category: "Decorations", image: "/services/decor.jpg", status: "Active", rating: "4.8", reviews: 62, tag: "Booked 2 this Month", title: "Grand Wedding Decoration", text: "Bespoke stage design, candelabra centerpieces and aisle styling.", price: 65000, unit: "Custom Concept" },
  { id: 3, category: "Catering", image: "/services/catering.jpg", status: "Active", rating: "4.7", reviews: 48, tag: "Min 60 guests", title: "Artisan Catering & Banquets", text: "Multi-course tailored culinary experiences with paired beverages.", price: 1500, unit: "Per Guest" },
  { id: 4, category: "Cake Icing", image: "/services/cake.jpg", status: "Active", rating: "4.9", reviews: 72, tag: "72 Orders", title: "Artisan Cake Design", text: "Handcrafted tiered masterworks with sugar-sculpted florals.", price: 12000, unit: "Tiered Sculpture" },
  { id: 5, category: "Makeup Artists", image: "/services/makeup.jpg", status: "Active", rating: "5.0", reviews: 41, tag: "On-location", title: "Haute Couture Bridal", text: "Luxury bridal styling, waterproof finishes and a trial session.", price: 25000, unit: "Bridal Suite Session" },
  { id: 6, category: "Dance Groups", image: "/services/dance.jpg", status: "Active", rating: "4.8", reviews: 28, tag: "6-dancer troupe", title: "Symphonic Dance Ensemble", text: "Traditional and modern masterworks with live music pairing.", price: 35000, unit: "Full Performance" },
  { id: 7, category: "Magicians", image: "/services/magic.jpg", status: "Draft", rating: "4.8", reviews: 19, tag: "Pending Pricing", title: "Cocktail Illusionist & Close-up", text: "Interactive close-up magic for cocktail hours and receptions.", price: 20000, unit: "Ready to Publish" },
  { id: 8, category: "Surprise Gifts", image: "/services/gifts.jpg", status: "Paused", rating: "4.8", reviews: 33, tag: "Seasonal hold", title: "Curated Surprise Gift Hampers", text: "Artisanal gift hampers delivered with a personal note.", price: 5000, unit: "Per Hamper" },
];

const topServices = [
  { name: "Grand Wedding Decoration", category: "Decorations", bookings: 19, conv: "18.6%", revenue: 1225000, trend: "+24%" },
  { name: "Wedding Photo & Cinema", category: "Photography", bookings: 14, conv: "12.1%", revenue: 630000, trend: "+18%" },
  { name: "Haute Couture Bridal Glam", category: "Makeup", bookings: 12, conv: "17.5%", revenue: 300000, trend: "+9%" },
  { name: "Artisan Cake Design", category: "Cake Icing", bookings: 9, conv: "12.5%", revenue: 108000, trend: "+4%" },
];

const health = [
  { label: "TOTAL VIEWS", value: "4,820", note: "+31% this week" },
  { label: "CONV. RATE", value: "14.6%", note: "Top 5% overall" },
  { label: "AVG RESPONSE", value: "22 min", note: "Optimal pace" },
  { label: "AVG RATING", value: "4.91 ★", note: "Across 249 reviews" },
];

const auditLog = [
  { title: "Floral Design", text: "2 hours ago • Sarah" },
  { title: "Wedding Photography", text: "Yesterday • Kevon" },
  { title: "Cocktail Illusionist", text: "3 days ago • Sarah" },
];

// ---------- HELPERS ----------
const lkr = (n) => n.toLocaleString("en-US");
const statusCss = { Active: "ok", Draft: "gray", Paused: "wait" };

// ---------- MAIN COMPONENT ----------
export default function MyServices() {
  const [page, setPage] = useState("My Services");
  const [services, setServices] = useState(firstServices);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [status, setStatus] = useState("All");
  const [sort, setSort] = useState("Newest");
  const [view, setView] = useState("grid"); // "grid" or "list"
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", category: "Photography", price: "" });

  // All category names found in the list (for the dropdown)
  const categories = [...new Set(services.map((s) => s.category))];

  // Counts for the four stat cards (calculated from the list)
  const count = (st) => services.filter((s) => s.status === st).length;
  const livePercent = services.length ? ((count("Active") / services.length) * 100).toFixed(1) : "0.0";

  // 1) filter  2) sort
  const shown = services
    .filter((s) => category === "All" || s.category === category)
    .filter((s) => status === "All" || s.status === status)
    .filter((s) => {
      const text = `${s.title} ${s.category} ${s.text}`.toLowerCase();
      return text.includes(search.toLowerCase());
    })
    .sort((a, b) => {
      if (sort === "Price: Low to High") return a.price - b.price;
      if (sort === "Price: High to Low") return b.price - a.price;
      if (sort === "Top Rated") return Number(b.rating) - Number(a.rating);
      return b.id - a.id; // Newest
    });

  function setServiceStatus(id, newStatus) {
    setServices(services.map((s) => (s.id === id ? { ...s, status: newStatus } : s)));
  }

  function resetFilters() {
    setSearch(""); setCategory("All"); setStatus("All"); setSort("Newest");
  }

  function addService(e) {
    e.preventDefault();
    if (!form.title.trim() || !form.price) return;
    const newService = {
      id: Date.now(), category: form.category, image: "", status: "Draft",
      rating: "0.0", reviews: 0, tag: "New draft", title: form.title,
      text: "Add a description for this service.", price: Number(form.price), unit: "Starting price",
    };
    setServices([newService, ...services]);
    setForm({ title: "", category: "Photography", price: "" });
    setShowForm(false);
  }

  function exportCatalog() {
    const rows = [["Title", "Category", "Status", "Price (LKR)"]];
    services.forEach((s) => rows.push([s.title, s.category, s.status, s.price]));
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    link.download = "my-services.csv";
    link.click();
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
  }

  const stats = [
    { icon: "📁", label: "TOTAL PORTFOLIO", value: services.length, pills: [`Across ${categories.length} Categories`, "100% Filled"] },
    { icon: "✔", label: "ACTIVE & BOOKABLE", value: count("Active"), pills: ["Accepting Inquiries", `${livePercent}% Live`] },
    { icon: "✏️", label: "IN PREPARATION", value: count("Draft"), pills: ["Needs Pricing Review", `${count("Draft")} Pending Approval`] },
    { icon: "📦", label: "ARCHIVED / PAUSED", value: count("Paused"), pills: ["Temporarily Paused", "Off-Season"] },
  ];

  return (
    <div className="ms">
      {/* ================= SIDEBAR ================= */}
      <aside className="ms-side">
        <div className="ms-brand">
          <span className="ms-logo">✦</span>
          <div><strong>Event Connect</strong><small>YOUR EVENT, PERFECTLY PLANNED</small></div>
        </div>

        <nav className="ms-menu">
          {menu.map((item) => (
            <button key={item.name} className={page === item.name ? "on" : ""} onClick={() => setPage(item.name)}>
              {item.name}
              {item.badge && <b className={`ms-badge ${item.badgeCss}`}>{item.badge}</b>}
            </button>
          ))}
          <button onClick={logout}>Logout</button>
        </nav>

        <div className="ms-help">
          <strong>Artisan Concierge</strong>
          <p>Need dedicated coordination assistance with VIP bookings?</p>
          <a href="#">Connect Now →</a>
        </div>
      </aside>

      {/* ================= MAIN ================= */}
      <div className="ms-main">
        <header className="ms-top">
          <input className="ms-search-top" placeholder="🔍 Search bookings, services, clients..." />
          <div className="ms-top-right">
            <button className="ms-icon" aria-label="Notifications">🔔<i></i></button>
            <button className="ms-icon" aria-label="Messages">💬<i></i></button>
            <div className="ms-profile">
              <span className="ms-avatar">L</span>
              <div><strong>Lumière Events</strong><small>Creative Director • Online</small></div>
            </div>
          </div>
        </header>

        <main className="ms-content">
          {/* ----- Title ----- */}
          <small className="ms-crumb">Home › <b>My Services</b></small>
          <div className="ms-title">
            <div>
              <h1>My Services <span className="ms-pill purple">CATALOGUE V2.4</span></h1>
              <p>Create, manage and showcase your event services to high-intent event hosts, luxury galas, and VIP clients across the island.</p>
            </div>
            <div className="ms-title-buttons">
              <button className="ms-btn white" onClick={exportCatalog}>⬇ Export Catalog</button>
              <button className="ms-btn dark" onClick={() => setShowForm(!showForm)}>+ Add New Service</button>
            </div>
          </div>

          {/* ----- Quick add form ----- */}
          {showForm && (
            <form className="ms-card ms-form" onSubmit={addService}>
              <input placeholder="Service title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {["Photography", "Decorations", "Catering", "Cake Icing", "Makeup Artists", "Dance Groups", "Magicians", "Surprise Gifts"].map((c) => <option key={c}>{c}</option>)}
              </select>
              <input type="number" placeholder="Starting price (LKR)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
              <button className="ms-btn dark" type="submit">Save as Draft</button>
            </form>
          )}

          {/* ----- Stats ----- */}
          <section className="ms-stats">
            {stats.map((s) => (
              <div className="ms-card ms-stat" key={s.label}>
                <div className="ms-stat-top"><small>{s.label}</small><span className="ms-icon-box">{s.icon}</span></div>
                <strong>{s.value}</strong>
                <div className="ms-pills">{s.pills.map((p) => <span key={p} className="ms-pill soft">{p}</span>)}</div>
              </div>
            ))}
          </section>

          {/* ----- Filters ----- */}
          <section className="ms-filters">
            <input placeholder="🔍 Search services by title, category, tag..." value={search} onChange={(e) => setSearch(e.target.value)} />
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="All">All Categories ({categories.length})</option>
              {categories.map((c) => <option key={c}>{c}</option>)}
            </select>
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="All">All Statuses</option>
              <option>Active</option><option>Draft</option><option>Paused</option>
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              {["Newest", "Top Rated", "Price: Low to High", "Price: High to Low"].map((option) => (
                <option key={option} value={option}>Sort by: {option}</option>
              ))}
            </select>
            <div className="ms-view">
              <button className={view === "grid" ? "on" : ""} onClick={() => setView("grid")} aria-label="Grid view">▦</button>
              <button className={view === "list" ? "on" : ""} onClick={() => setView("list")} aria-label="List view">☰</button>
            </div>
          </section>

          <div className="ms-count-row">
            <small>Showing {shown.length} of {services.length} services • ⚡ Instant Booking Active for {count("Active")} items</small>
            <div><button>⇅ Bulk Reorder</button><button onClick={resetFilters}>↺ Reset Filters</button></div>
          </div>

          {/* ----- Service cards ----- */}
          {shown.length === 0 && <p className="ms-empty">No services match your filters.</p>}
          <section className={`ms-cards ${view}`}>
            {shown.map((s) => (
              <article className="ms-card ms-service" key={s.id}>
                <div className="ms-service-img" style={s.image ? { backgroundImage: `url(${s.image})` } : {}}>
                  <div className="ms-chips">
                    <span className="ms-chip dark">{s.category.toUpperCase()}</span>
                    <span className={`ms-chip ${statusCss[s.status]}`}>● {s.status}</span>
                  </div>
                  <div className="ms-img-bottom">
                    <span className="ms-chip dark">★ {s.rating} ({s.reviews})</span>
                    <span className="ms-chip glass">{s.tag}</span>
                  </div>
                </div>

                <div className="ms-service-body">
                  <h4>{s.title}</h4>
                  <p>{s.text}</p>
                  <div className="ms-price">
                    <small>STARTING AT</small>
                    <div><b>LKR {lkr(s.price)}</b><small>{s.unit}</small></div>
                  </div>
                  <div className="ms-actions">
                    <span className="ms-mini-icons">👁 ⎘ ⋯</span>
                    {s.status === "Draft" && <button className="ms-btn gold small" onClick={() => setServiceStatus(s.id, "Active")}>⬆ Publish</button>}
                    {s.status === "Paused" && <button className="ms-btn outline small" onClick={() => setServiceStatus(s.id, "Active")}>Activate</button>}
                    {s.status === "Active" && (
                      <>
                        <button className="ms-btn light small" onClick={() => setServiceStatus(s.id, "Paused")}>Pause</button>
                        <button className="ms-btn dark small">✎ Edit</button>
                      </>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </section>

          {/* ----- Bottom: top services + catalog health ----- */}
          <div className="ms-bottom">
            <section className="ms-card">
              <div className="ms-head"><h3>🏆 Top-Performing Services</h3><small>LAST 30 DAYS</small></div>
              <div className="ms-table-wrap">
                <table>
                  <thead><tr><th>SERVICE NAME</th><th>CATEGORY</th><th>BOOKINGS</th><th>CONV. RATE</th><th>REVENUE (LKR)</th><th>TREND</th></tr></thead>
                  <tbody>
                    {topServices.map((t) => (
                      <tr key={t.name}>
                        <td><b>{t.name}</b></td><td>{t.category}</td><td>{t.bookings}</td>
                        <td className="green">{t.conv}</td><td>{lkr(t.revenue)}</td><td className="green">{t.trend}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="ms-total"><small>Monthly Revenue Attributed to Services</small><b>LKR {lkr(topServices.reduce((sum, t) => sum + t.revenue, 0))}</b></div>
            </section>

            <section className="ms-card">
              <div className="ms-head"><h3>Catalog Health</h3></div>
              <div className="ms-health">
                {health.map((h) => (
                  <div key={h.label}><small>{h.label}</small><b>{h.value}</b><span className="ms-pill soft">{h.note}</span></div>
                ))}
              </div>
              <small className="ms-log-title">AUDIT & UPDATE LOG</small>
              <ul className="ms-log">
                {auditLog.map((l) => <li key={l.title}><i></i><div><b>{l.title}</b><small>{l.text}</small></div></li>)}
              </ul>
              <a href="#" className="ms-link">View Complete Catalog Audit Logs</a>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}
