import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/home";
import Login from "./components/Login/Login";
import Register from "./components/Register/Register";
import CustomerHome from "./components/ClientDashboard/CustomerHome";
import BrowseServices from "./components/ClientDashboard/BrowseServices";
import EventConnectBookings from "./components/ClientDashboard/EventConnectBookings";
import EventConnectProfile from "./components/ClientDashboard/EventConnectProfile";
import EventConnectMessages from "./components/ClientDashboard/EventConnectMessages";
import ProviderHome from "./components/ServiceProviderDashboard/ProviderHome";
import ProviderDashboard from "./components/ProviderDashboard/ProviderDashboard";
import AdminDashboard from "./components/AdminDashboard/AdminDashboard";

function NotFound() {
  return <main style={{ padding: "48px 24px", textAlign: "center" }}>
    <h1>404 - Page not found</h1><a href="/">Back to Home</a>
  </main>;
}

export default function App() {
  return <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/CustomerHome" element={<CustomerHome />} />
    <Route path="/BrowseServices" element={<BrowseServices />} />
    <Route path="/MyBookings" element={<EventConnectBookings />} />
    <Route path="/Messages" element={<EventConnectMessages />} />
    <Route path="/MyProfile" element={<EventConnectProfile />} />
    <Route path="/ProviderHome" element={<ProviderHome />} />
    <Route path="/ProviderDashboard" element={<ProviderDashboard />} />
    <Route path="/AdminDashboard" element={<AdminDashboard />} />
    <Route path="/dashboard" element={<Navigate to="/CustomerHome" replace />} />
    <Route path="*" element={<NotFound />} />
  </Routes>;
}
