import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

export default function Login() {
  // navigate("/") moves the user to another page (needs React Router)
  const navigate = useNavigate();

  // useState = React's "memory" for what the user types
  const [form, setForm] = useState({ username: "", password: "" });
  const [message, setMessage] = useState("");

  // One function handles both inputs (uses each input's "name")
  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  // "async" lets us use "await" to wait for the server's answer
  function handleSubmit(e) {
    e.preventDefault();

    if (!form.username.trim() || !form.password) {
      setMessage("Please enter your user name and password.");
      return;
    }

    // Frontend demo only: no API/backend authentication.
    const user = { username: form.username.trim(), role: "customer" };
    localStorage.setItem("user", JSON.stringify(user));
    setMessage(`Welcome, ${user.username}!`);
    navigate("/CustomerHome");
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1>LOGIN</h1>

        <label htmlFor="username">User Name</label>
        <input
          id="username"
          name="username"
          type="text"
          value={form.username}
          onChange={handleChange}
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          name="password"
          type="text"
          value={form.password}
          onChange={handleChange}
        />

        <button type="submit" className="pill-btn">Login</button>

        {message && <p className="login-message">{message}</p>}

        <p className="no-account">If you don't have an account</p>

        {/* Link to the Register page (works once you add React Router) */}
        <button type="button" className="pill-btn" onClick={() => navigate("/register")}>Register</button>
      </form>
    </div>
  );
}
