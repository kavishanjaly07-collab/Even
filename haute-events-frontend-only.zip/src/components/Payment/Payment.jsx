import { useState } from "react";
import "./Payment.css";

export default function Payment() {
  // useState = React's "memory" for what the user types
  const [form, setForm] = useState({
    cardName: "",
    cardNumber: "",
    expireDate: "",
    cvv: "",
  });
  const [message, setMessage] = useState("");

  // One function handles all inputs (uses each input's "name")
  function handleChange(e) {
    const { name, value } = e.target;

    // For number fields, keep only digits (remove letters and symbols)
    if (name === "cardNumber" || name === "cvv") {
      setForm({ ...form, [name]: value.replace(/\D/g, "") });
    } else {
      setForm({ ...form, [name]: value });
    }
  }

  function handleSubmit(e) {
    e.preventDefault(); // stops the page from reloading

    if (!form.cardName || !form.cardNumber || !form.expireDate || !form.cvv) {
      setMessage("Please fill in all fields.");
      return;
    }
    if (form.cardNumber.length !== 16) {
      setMessage("Card number must be 16 digits.");
      return;
    }
    if (form.cvv.length < 3) {
      setMessage("CVV must be 3 digits.");
      return;
    }

    // Later: connect a real payment service here (see notes)
    setMessage("Payment details look good! ✅");
  }

  return (
    <div className="payment-page">
      <form className="payment-card" onSubmit={handleSubmit}>
        <h1>PAYMENT</h1>

        <label htmlFor="cardName">Card Name</label>
        <input
          id="cardName"
          name="cardName"
          type="text"
          value={form.cardName}
          onChange={handleChange}
        />

        <label htmlFor="cardNumber">Card number</label>
        <input
          id="cardNumber"
          name="cardNumber"
          type="text"
          inputMode="numeric"
          maxLength={16}
          value={form.cardNumber}
          onChange={handleChange}
        />

        {/* Expire date and CVV sit side by side */}
        <div className="row">
          <div className="column">
            <label htmlFor="expireDate">Expire date</label>
            <input
              id="expireDate"
              name="expireDate"
              type="month"
              value={form.expireDate}
              onChange={handleChange}
            />
          </div>

          <div className="column">
            <label htmlFor="cvv">CVV code</label>
            <input
              id="cvv"
              name="cvv"
              type="password"
              inputMode="numeric"
              maxLength={3}
              value={form.cvv}
              onChange={handleChange}
            />
          </div>
            <div className="column">
            <label htmlFor="Vendor ">Vendor Type</label>
            <input
              id="Vendor"
              name="Vendor"
              type="text"
              value={form.Vendor}
              onChange={handleChange}
            />
          </div>
        </div>

        <button type="submit" className="pay-btn">PAY</button>
        {message && <p className="payment-message">{message}</p>}
      </form>
    </div>
  );
}
