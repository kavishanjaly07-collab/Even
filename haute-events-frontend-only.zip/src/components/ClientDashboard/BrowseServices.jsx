import React, { useMemo, useState } from "react";
import "./BrowseServices.css";

const categories = [
  { name: "Photography", icon: "📸", count: 42 },
  { name: "Decor & Flowers", icon: "💐", count: 36 },
  { name: "Catering", icon: "🍽️", count: 29 },
  { name: "Cake & Sweets", icon: "🎂", count: 18 },
  { name: "Makeup Artist", icon: "💄", count: 14 },
  { name: "Surprise & Gifts", icon: "🎁", count: 21 },
  { name: "Dance & Music", icon: "🎭", count: 13 },
  { name: "Magicians", icon: "✨", count: 11 },
];

const services = [
  {
    id: 1,
    name: "Lumière Lens & Cinema",
    category: "Photography",
    description: "Fine-art documentary cinematography with a timeless, elegant style.",
    price: 180,
    rating: "4.9",
    reviews: 121,
    availability: "Available this weekend",
    tag: "15% OFF",
    image:
      "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 2,
    name: "Velvet Bloom Floral & Decor",
    category: "Decor & Flowers",
    description: "Beautiful floral architecture, botanical centerpieces and event styling.",
    price: 220,
    rating: "4.8",
    reviews: 96,
    availability: "Available: Nov 20, 2026",
    tag: "Featured",
    image:
      "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 3,
    name: "Saffron & Sage Fine Catering",
    category: "Catering",
    description: "Multi-course curated gastronomy, plant-forward menus and elegant service.",
    price: 75,
    suffix: "/ person",
    rating: "4.9",
    reviews: 75,
    availability: "Available: Custom dates",
    tag: "Trending Available",
    image:
      "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 4,
    name: "La Petite Pâtisserie & Cakes",
    category: "Cake & Sweets",
    description: "Artisanal tiered wedding cakes, delicate macarons and custom desserts.",
    price: 450,
    rating: "5.0",
    reviews: 57,
    availability: "Available: 48h notice",
    tag: "Award Winner",
    image:
      "https://images.unsplash.com/photo-1535254973040-607b474cb50d?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 5,
    name: "Glow & Glamour Beauty Studio",
    category: "Makeup Artist",
    description: "Editorial bridal makeup, natural beauty and camera-ready finishes.",
    price: 320,
    rating: "4.9",
    reviews: 112,
    availability: "Available: Get a quote",
    tag: "",
    image:
      "https://images.unsplash.com/photo-1522335789203-aabad1fc54bc?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 6,
    name: "Astonish Illusions & Magic",
    category: "Magicians",
    description: "Sophisticated mind-reading, close-up magic and unforgettable shows.",
    price: 850,
    rating: "4.9",
    reviews: 54,
    availability: "Available: Fri / Sat",
    tag: "Top Rated",
    image:
      "https://images.unsplash.com/photo-1503095396549-807759245b35?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 7,
    name: "Rhythm Royale Dance Troupe",
    category: "Dance & Music",
    description: "High-energy choreography, grand ballroom performances and vibrant routines.",
    price: 1100,
    rating: "4.8",
    reviews: 45,
    availability: "Available: Select dates",
    tag: "",
    image:
      "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 8,
    name: "Heartfelt Surprises & Balloons",
    category: "Surprise & Gifts",
    description: "Dreamlike balloon installations, custom oversized gifts and surprises.",
    price: 180,
    rating: "4.9",
    reviews: 78,
    availability: "Available: Same day",
    tag: "Fast Booking",
    image:
      "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=800&q=85",
  },
];

function SidebarItem({ icon, children, active, onClick }) {
  return (
    <button className={`sidebar-item ${active ? "active" : ""}`} onClick={onClick}>
      <span className="sidebar-icon">{icon}</span>
      <span>{children}</span>
    </button>
  );
}

export default function BrowseServices() {
  const [activeNav, setActiveNav] = useState("Browse Services");
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("Recommended");
  const [showDiscounts, setShowDiscounts] = useState(false);
  const [favorites, setFavorites] = useState([]);
  const [notice, setNotice] = useState("");

  const filteredServices = useMemo(() => {
    let result = services.filter((service) => {
      const matchesCategory =
        activeCategory === "All" || service.category === activeCategory;
      const query = search.trim().toLowerCase();
      const matchesSearch =
        !query ||
        service.name.toLowerCase().includes(query) ||
        service.category.toLowerCase().includes(query) ||
        service.description.toLowerCase().includes(query);
      const matchesDiscount = !showDiscounts || Boolean(service.tag);
      return matchesCategory && matchesSearch && matchesDiscount;
    });

    if (sortBy === "Price: low to high") result = [...result].sort((a, b) => a.price - b.price);
    if (sortBy === "Price: high to low") result = [...result].sort((a, b) => b.price - a.price);
    if (sortBy === "Top rated") result = [...result].sort((a, b) => Number(b.rating) - Number(a.rating));
    return result;
  }, [activeCategory, search, showDiscounts, sortBy]);

  const toggleFavorite = (id) => {
    setFavorites((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id]
    );
  };

  const handleAction = (message) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2800);
  };

  return (
    <div className="ec-app">
      <aside className="ec-sidebar">
        <div className="brand">
          <div className="brand-mark">✦</div>
          <div>
            <div className="brand-name">EventConnect</div>
            <div className="brand-subtitle">PREMIER ATELIER</div>
          </div>
        </div>

        <nav className="sidebar-nav" aria-label="Main navigation">
          <SidebarItem icon="⌂" active={activeNav === "Overview"} onClick={() => setActiveNav("Overview")}>Overview</SidebarItem>
          <SidebarItem icon="▦" active={activeNav === "Browse Services"} onClick={() => setActiveNav("Browse Services")}>Browse Services</SidebarItem>
          <SidebarItem icon="▣" active={activeNav === "My Bookings"} onClick={() => setActiveNav("My Bookings")}>My Bookings</SidebarItem>
          <SidebarItem icon="▤" active={activeNav === "Payments & Budget"} onClick={() => setActiveNav("Payments & Budget")}>Payments &amp; Budget</SidebarItem>
          <SidebarItem icon="✉" active={activeNav === "Messages"} onClick={() => setActiveNav("Messages")}>Messages</SidebarItem>
          <SidebarItem icon="☆" active={activeNav === "My Reviews"} onClick={() => setActiveNav("My Reviews")}>My Reviews</SidebarItem>
          <SidebarItem icon="♙" active={activeNav === "My Profile"} onClick={() => setActiveNav("My Profile")}>My Profile</SidebarItem>
        </nav>

        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-title">✦ Concierge Help</div>
            <p>Need private styling or vendor coordination assistance?</p>
            <button onClick={() => handleAction("Concierge support request started.")}>Connect Live</button>
          </div>
          <button className="logout-button" onClick={() => handleAction("Logout can be connected to your authentication flow.")}>
            ↪ <span>Log Out</span>
          </button>
        </div>
      </aside>

      <main className="ec-main">
        <header className="topbar">
          <div className="top-search">
            <span>⌕</span>
            <input
              aria-label="Search services"
              placeholder="Search services, verified vendors, cakes, catering..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            <kbd>⌘ K</kbd>
          </div>
          <div className="topbar-actions">
            <button className="icon-button" aria-label="Notifications" onClick={() => handleAction("You're all caught up!")}>♧<i /></button>
            <button className="icon-button" aria-label="Messages" onClick={() => setActiveNav("Messages")}>▤</button>
            <div className="profile-mini">
              <div className="avatar">A</div>
              <div><strong>Alex Johnson <span className="vip-pill">VIP</span></strong><small>Private Host</small></div>
              <span className="chevron">⌄</span>
            </div>
          </div>
        </header>

        <section className="intro-panel">
          <div className="intro-copy">
            <div className="eyebrow"><span>CURATED EXPERIENCES</span> Artisan Collective / Where Moments Become</div>
            <h1>Curated Event Artisans &amp; Services</h1>
            <p>Find exceptional professionals to make your next event unforgettable.</p>
          </div>
          <div className="intro-right">
            <span className="online-count"><i /> 628 verified artisans online</span>
            <span className="verified-pill">✓ Vetted Standards</span>
          </div>
          <div className="discovery-search">
            <span className="search-symbol">⌕</span>
            <input
              placeholder="Search by vendor name, service, or keyword (e.g. Vintage Photobooth, Vegan Catering, Silk...)"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            <button onClick={() => document.querySelector(".services-grid")?.scrollIntoView({ behavior: "smooth", block: "start" })}>Discover <span>→</span></button>
          </div>
          <div className="filter-row">
            <button className="filter-chip" onClick={() => setActiveCategory("All")}>♧ Category: <b>{activeCategory}</b>⌄</button>
            <button className="filter-chip" onClick={() => setSortBy(sortBy === "Top rated" ? "Recommended" : "Top rated")}>♧ <b>5★</b> <b>$$$$</b></button>
            <button className="filter-chip" onClick={() => setSortBy(sortBy === "Price: low to high" ? "Recommended" : "Price: low to high")}>✧ Min Rating: <b>4.8+</b>⌄</button>
            <button className="filter-chip" onClick={() => handleAction("Choose your event date when booking a service.")}>▦ Date: <b>Any Upcoming</b>⌄</button>
            <button className={`filter-chip discount-filter ${showDiscounts ? "selected" : ""}`} onClick={() => setShowDiscounts(!showDiscounts)}>
              <span className="empty-checkbox">{showDiscounts ? "✓" : ""}</span> Promotions &amp; Offers <b className="discount-label">{showDiscounts ? "ON" : "15% OFF"}</b>
            </button>
          </div>
          <div className="filter-footnote"><span>Reset</span><span>Sorted by: <b>{sortBy}</b></span></div>
        </section>

        <section className="category-section">
          <div className="section-heading">
            <h2><span className="purple-dot" /> Artisan Specialties</h2>
            <button onClick={() => setActiveCategory("All")}>View directory map ↗</button>
          </div>
          <div className="category-list">
            {categories.map((category) => (
              <button
                key={category.name}
                className={`category-card ${activeCategory === category.name ? "chosen" : ""}`}
                onClick={() => setActiveCategory(activeCategory === category.name ? "All" : category.name)}
              >
                <span className="category-icon">{category.icon}</span>
                <strong>{category.name}</strong>
                <small>{category.count} Artisans</small>
              </button>
            ))}
          </div>
        </section>

        <section className="services-section">
          <div className="section-heading service-heading">
            <div>
              <h2><span className="purple-dot" /> Available Services</h2>
              <p>Showing <b>{filteredServices.length}</b> of 628 curated creations</p>
            </div>
            <div className="view-buttons">
              <button className="view-button selected" aria-label="Grid view">▦</button>
              <button className="view-button" aria-label="List view" onClick={() => handleAction("Grid view is currently selected.")}>☷</button>
            </div>
          </div>

          {filteredServices.length > 0 ? (
            <div className="services-grid">
              {filteredServices.map((service) => (
                <article className="service-card" key={service.id}>
                  <div className="service-image-wrap">
                    <img src={service.image} alt={service.category} className="service-image" />
                    {service.tag && <span className={`service-tag tag-${service.id}`}>{service.tag}</span>}
                    <button
                      className={`favorite-button ${favorites.includes(service.id) ? "is-favorite" : ""}`}
                      aria-label={favorites.includes(service.id) ? "Remove from favorites" : "Add to favorites"}
                      onClick={() => toggleFavorite(service.id)}
                    >{favorites.includes(service.id) ? "♥" : "♡"}</button>
                    <div className="image-category">{service.category.toUpperCase()}</div>
                  </div>
                  <div className="service-info">
                    <div className="service-title-row">
                      <h3>{service.name}</h3>
                      <span className="rating">★ {service.rating} <small>({service.reviews})</small></span>
                    </div>
                    <p className="service-description">{service.description}</p>
                    <div className="service-price-row">
                      <div><small>Starting Rate</small><strong>${service.price.toLocaleString()}{service.suffix || ""}</strong></div>
                      <div className="availability"><span />{service.availability}</div>
                    </div>
                    <div className="service-actions">
                      <button className="outline-button" onClick={() => handleAction(`${service.name}: details panel can be connected here.`)}>View Details</button>
                      <button className="primary-button" onClick={() => handleAction(`Booking started for ${service.name}.`)}>Book Now</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <span>⌕</span>
              <h3>No services found</h3>
              <p>Try another search or select a different category.</p>
              <button className="primary-button" onClick={() => { setSearch(""); setActiveCategory("All"); setShowDiscounts(false); }}>Clear filters</button>
            </div>
          )}
          <div className="pagination">
            <span>Showing <b>1–{filteredServices.length}</b> of 628 providers</span>
            <div>
              <button disabled aria-label="Previous page">‹</button>
              <button className="current-page">1</button>
              <button onClick={() => handleAction("Connect pagination to your services API.")}>2</button>
              <button onClick={() => handleAction("Connect pagination to your services API.")}>3</button>
              <span>...</span>
              <button onClick={() => handleAction("Connect pagination to your services API.")}>29</button>
              <button onClick={() => handleAction("Connect pagination to your services API.")} aria-label="Next page">›</button>
            </div>
          </div>
        </section>
      </main>
      {notice && <div className="ec-toast" role="status">{notice}</div>}
    </div>
  );
}
