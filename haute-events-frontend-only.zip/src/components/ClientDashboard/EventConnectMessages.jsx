import React, { useMemo, useState } from "react";
import "./EventConnectMessages.css";

const conversations = [
  {
    id: 1,
    name: "Lumière Lens & Co",
    initials: "LL",
    avatar: "🌅",
    time: "10:24 AM",
    preview: "Elena Vance: We have finalized the...",
    tag: "CINEMATOGRAPHY",
    unread: 2,
    active: true,
  },
  {
    id: 2,
    name: "SoundWave AV & Stage",
    initials: "SW",
    avatar: "🎧",
    time: "Yesterday",
    preview: "Marcus Boyd: The stage lighting...",
    tag: "AUDIOVISUAL",
  },
  {
    id: 3,
    name: "Velvet Bloom Floral",
    initials: "VB",
    avatar: "🌷",
    time: "Oct 18",
    preview: "Camilla Chen: We sourced the...",
    tag: "FLORAL CURATION",
  },
  {
    id: 4,
    name: "Artisan Gourmet Catered",
    initials: "AG",
    avatar: "🍰",
    time: "Oct 15",
    preview: "Chef Julian: Tastings session...",
    tag: "HAUTE CUISINE",
  },
  {
    id: 5,
    name: "Concierge VIP Desk",
    initials: "CV",
    avatar: "✦",
    time: "Oct 12",
    preview: "Support Specialist: Your bespoke...",
    tag: "PLATFORM CONCIERGE",
  },
];

const initialMessages = [
  {
    id: 1,
    from: "vendor",
    name: "Elena Vance",
    time: "4:05 PM",
    text: "Hello! As I reviewed the Grand Pavilion floor plan and lighting conditions for the evening reception. We love the dramatic ambient palette you've chosen.",
  },
  {
    id: 2,
    from: "me",
    name: "Alex Johnson",
    time: "4:30 PM",
    text: "Hi Elena, that's great! Will you be able to bring the second camera operator for the cocktail hour? We want to ensure we capture spontaneous arrival moments.",
    read: true,
  },
  {
    id: 3,
    from: "vendor",
    name: "Elena Vance",
    time: "4:45 PM",
    text: "Yes, exactly! Mark will be covering guest arrivals while I capture the grand entrance. Here is the revised schedule.",
  },
];

function Icon({ children, className = "" }) {
  return <span className={`ec-icon ${className}`} aria-hidden="true">{children}</span>;
}

export default function EventConnectMessages() {
  const [activeConversation, setActiveConversation] = useState(1);
  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");
  const [messagesByConversation, setMessagesByConversation] = useState({
    1: initialMessages,
  });
  const [showNewInquiry, setShowNewInquiry] = useState(false);

  const active = conversations.find((item) => item.id === activeConversation) || conversations[0];
  const messages = messagesByConversation[activeConversation] || (
    activeConversation === 1 ? initialMessages : [
      {
        id: 1,
        from: "vendor",
        name: active.name,
        time: "Today",
        text: `Hello! Thank you for reaching out to ${active.name}. How can we help with your event?`,
      },
    ]
  );

  const filteredConversations = useMemo(() => conversations.filter((item) => {
    const query = search.toLowerCase();
    const matchesSearch = `${item.name} ${item.preview} ${item.tag}`.toLowerCase().includes(query);
    const matchesTag = !vendorFilter || item.tag.toLowerCase().includes(vendorFilter.toLowerCase());
    return matchesSearch && matchesTag;
  }), [search, vendorFilter]);

  function sendMessage(event) {
    event.preventDefault();
    const trimmed = message.trim();
    if (!trimmed) return;
    const nextMessage = {
      id: Date.now(),
      from: "me",
      name: "Alex Johnson",
      time: "Just now",
      text: trimmed,
      read: true,
    };
    setMessagesByConversation((current) => ({
      ...current,
      [activeConversation]: [...(current[activeConversation] || messages), nextMessage],
    }));
    setMessage("");
  }

  return (
    <div className="ec-page">
      <div className="ec-app">
        <aside className="ec-sidebar">
          <div className="ec-brand">
            <div className="ec-brand-mark">✦</div>
            <div>
              <div className="ec-brand-name">Event Connect</div>
              <div className="ec-brand-subtitle">PREMIER ATELIER</div>
            </div>
          </div>

          <nav className="ec-nav" aria-label="Main navigation">
            {[
              ["Overview", "⌂"],
              ["Browse Services", "⌕"],
              ["My Bookings", "▤"],
              ["Payments & Budget", "◈"],
              ["Messages", "▣"],
              ["My Reviews", "☆"],
              ["My Profile", "♙"],
            ].map(([label, icon]) => (
              <button
                className={`ec-nav-item ${label === "Messages" ? "is-current" : ""}`}
                key={label}
                type="button"
                onClick={() => label !== "Messages" && window.alert(`${label} page preview`)}
              >
                <span className="ec-nav-symbol">{icon}</span>
                {label}
                {label === "Messages" && <span className="ec-nav-active-dot" />}
              </button>
            ))}
          </nav>

          <div className="ec-sidebar-bottom">
            <div className="ec-help-card">
              <div className="ec-help-title"><span>✺</span> Concierge Help</div>
              <p>Need private styling or vendor coordination assistance?</p>
              <button type="button" onClick={() => window.alert("Connecting you with the concierge team…")}>Connect Live</button>
            </div>
            <button className="ec-logout" type="button" onClick={() => window.alert("You have been logged out in this demo.")}>
              <span>↪</span> Log Out
            </button>
          </div>
        </aside>

        <main className="ec-main">
          <header className="ec-topbar">
            <label className="ec-global-search">
              <Icon>⌕</Icon>
              <input placeholder="Search services, verified vendors, cakes, catering..." />
              <kbd>⌘ K</kbd>
            </label>
            <div className="ec-top-actions">
              <button className="ec-top-icon" type="button" aria-label="Notifications">♧<i /></button>
              <button className="ec-top-icon ec-bag" type="button" aria-label="Bookings">▣<i /></button>
              <div className="ec-user">
                <div className="ec-user-avatar">A</div>
                <div className="ec-user-copy"><strong>Alex Johnson</strong><span>Private Host</span></div>
                <span className="ec-vip">VIP</span>
              </div>
            </div>
          </header>

          <section className="ec-heading">
            <div>
              <div className="ec-eyebrow"><span>✦</span> SECURE ATELIER DISPATCH</div>
              <h1>Messages</h1>
            </div>
            <div className="ec-heading-actions">
              <label className="ec-filter-search">
                <Icon>⌕</Icon>
                <input value={vendorFilter} onChange={(e) => setVendorFilter(e.target.value)} placeholder="Filter dialogues or vendors..." />
              </label>
              <button className="ec-primary-button" type="button" onClick={() => setShowNewInquiry(true)}>
                <span>✉</span> New Inquiry
              </button>
            </div>
          </section>

          <section className="ec-messaging">
            <aside className="ec-conversations">
              <div className="ec-conversation-heading">
                <h2>Conversations</h2>
                <span className="ec-active-count">5 Active</span>
              </div>
              <div className="ec-pills">
                <button className="is-selected" type="button" onClick={() => setVendorFilter("")}>All (5)</button>
                <button type="button" onClick={() => setVendorFilter("CINEMATOGRAPHY")}>Active Bookings (1)</button>
                <button type="button" onClick={() => setVendorFilter("PLATFORM")}>Concierge</button>
              </div>
              <label className="ec-conversation-search">
                <Icon>⌕</Icon>
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search conversations..." />
              </label>
              <div className="ec-conversation-list">
                {filteredConversations.map((conversation) => (
                  <button
                    type="button"
                    className={`ec-conversation ${activeConversation === conversation.id ? "is-active" : ""}`}
                    key={conversation.id}
                    onClick={() => setActiveConversation(conversation.id)}
                  >
                    <span className={`ec-avatar ec-avatar-${conversation.id}`}>{conversation.avatar}</span>
                    <span className="ec-conversation-copy">
                      <span className="ec-conversation-top"><strong>{conversation.name}</strong><time>{conversation.time}</time></span>
                      <span className="ec-preview">{conversation.preview}</span>
                      <span className="ec-tag">{conversation.tag}</span>
                    </span>
                    {conversation.unread && activeConversation !== conversation.id && <span className="ec-unread">{conversation.unread}</span>}
                  </button>
                ))}
                {filteredConversations.length === 0 && <div className="ec-empty">No conversations found.</div>}
              </div>
            </aside>

            <section className="ec-chat">
              <header className="ec-chat-header">
                <div className="ec-chat-person">
                  <span className="ec-avatar ec-avatar-1">{active.avatar}</span>
                  <div>
                    <h2>{activeConversation === 1 ? "Elena Vance" : active.name}</h2>
                    <div className="ec-chat-meta">
                      <span className="ec-status-dot" /> CINEMATOGRAPHY &amp; PHOTOGRAPHY
                      <span className="ec-lavender-tag">✦ Lumière Lens &amp; Co</span>
                    </div>
                    <div className="ec-chat-submeta">Event Coordinator <span>•</span> Sophia's Bridal Gala Dinner <span>(#EC-849720)</span></div>
                  </div>
                </div>
                <div className="ec-chat-tools">
                  <button type="button" aria-label="Call vendor" onClick={() => window.alert("Calling vendor…")}>☎</button>
                  <button type="button" aria-label="Video call" onClick={() => window.alert("Starting video call…")}>▣</button>
                  <button type="button" className="ec-view-booking" onClick={() => window.alert("Booking details preview")}>▤ View Booking</button>
                </div>
              </header>

              <div className="ec-chat-body">
                <div className="ec-date-chip">YESTERDAY • OCTOBER 19</div>
                {messages.map((item) => (
                  <div className={`ec-message-row ${item.from === "me" ? "from-me" : "from-vendor"}`} key={item.id}>
                    {item.from !== "me" && <span className="ec-mini-avatar">🌿</span>}
                    <div className="ec-message-content">
                      <div className="ec-message-meta"><strong>{item.name}</strong><span>{item.time}</span></div>
                      <div className="ec-message-bubble">{item.text}</div>
                      {item.read && <div className="ec-read-receipt">✓ Seen by Elena</div>}
                    </div>
                    {item.from === "me" && <span className="ec-mini-avatar ec-mini-user">A</span>}
                  </div>
                ))}
                <div className="ec-date-chip ec-today-chip">TODAY • OCTOBER 20</div>
              </div>

              <form className="ec-composer" onSubmit={sendMessage}>
                <div className="ec-composer-tools">
                  <button type="button" aria-label="Attach file" onClick={() => window.alert("File attachment is not enabled in this demo.")}>♧</button>
                  <button type="button" aria-label="Add image" onClick={() => window.alert("Image attachment is not enabled in this demo.")}>▧</button>
                  <button type="button" aria-label="Add emoji" onClick={() => setMessage((value) => `${value} 😊`)}>☻</button>
                </div>
                <input
                  value={message}
                  onChange={(event) => setMessage(event.target.value)}
                  placeholder={`Type your message to ${activeConversation === 1 ? "Elena Vance" : active.name}...`}
                  aria-label="Message"
                />
                <button className="ec-send-button" type="submit">SEND <span>➤</span></button>
                <div className="ec-composer-footer"><span>♙ End-to-end encrypted VIP atelier communications</span><span>Press <kbd>Enter</kbd> to dispatch</span></div>
              </form>
            </section>
          </section>
        </main>

        {showNewInquiry && (
          <div className="ec-modal-backdrop" role="presentation" onClick={() => setShowNewInquiry(false)}>
            <form className="ec-inquiry-modal" onSubmit={(event) => { event.preventDefault(); setShowNewInquiry(false); window.alert("Inquiry saved in this demo."); }} onClick={(event) => event.stopPropagation()}>
              <button className="ec-modal-close" type="button" onClick={() => setShowNewInquiry(false)} aria-label="Close">×</button>
              <div className="ec-eyebrow">SECURE ATELIER DISPATCH</div>
              <h2>Start a new inquiry</h2>
              <p>Send a private message to a trusted event partner.</p>
              <label>Vendor
                <select defaultValue="Lumière Lens & Co">
                  {conversations.map((item) => <option key={item.id}>{item.name}</option>)}
                </select>
              </label>
              <label>Subject<input required placeholder="e.g. Reception photography schedule" /></label>
              <label>Message<textarea required placeholder="Tell the vendor a little about your request..." rows="4" /></label>
              <button className="ec-primary-button" type="submit">Send Inquiry <span>➤</span></button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
