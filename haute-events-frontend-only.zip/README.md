# Haute Events — Frontend Only

React + Vite frontend only. The Backend folder and API server have been excluded.

## Run
1. Open a terminal in this folder.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local URL printed by Vite.

## Routes
- `/` — Home
- `/login` — Login (frontend demo)
- `/register` — Register (frontend demo)
- `/CustomerHome` — Customer home
- `/BrowseServices` — Browse services
- `/MyBookings` — My bookings
- `/Messages` — Messages
- `/MyProfile` — Profile
- `/ProviderHome` — Provider home
- `/ProviderDashboard` — Provider dashboard
- `/AdminDashboard` — Admin dashboard

Login and registration are frontend-only demos. They store a basic profile in browser `localStorage`; no credentials are verified and no server/API is contacted. Dashboard data is sample frontend data.
